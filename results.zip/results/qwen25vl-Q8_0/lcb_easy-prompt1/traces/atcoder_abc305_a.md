# atcoder_abc305_a — PASS (1/3 attempts passed)

````json
{
  "id": "atcoder_abc305_a",
  "title": "Water Station",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2023-06-10",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
There is an ultramarathon course totaling 100\;\mathrm{km}.
Water stations are set up every 5\;\mathrm{km} along the course, including the start and goal, for a total of 21.
Takahashi is at the N\;\mathrm{km} point of this course.
Find the position of the nearest water station to him.
Under the constraints of this problem, it can be proven that the nearest water station is uniquely determined.

Input

The input is given from Standard Input in the following format:
N

Output

Print the distance between the start and the water station nearest to Takahashi, in kilometers, in a single line.

Constraints


- 0\leq N\leq100
- N is an integer.

Sample Input 1

53

Sample Output 1

55

Takahashi is at the 53\;\mathrm{km} point of the course.
The water station at the 55\;\mathrm{km} point is 2\;\mathrm{km} away, and there is no closer water station.
Therefore, you should print 55.

Sample Input 2

21

Sample Output 2

20

Takahashi could also go back the way.

Sample Input 3

100

Sample Output 3

100

There are also water stations at the start and goal.
Additionally, Takahashi may already be at a water station.

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 10,
  "num_tests": 10,
  "finish_reason": "stop",
  "prompt_tokens": 484,
  "completion_tokens": 301,
  "gen_seconds": 6.5,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to find the nearest water station to the given position \(N\) on the ultramarathon course. Since the water stations are set up every 5 km and there are 21 stations, the stations are at the positions \(0, 5, 10, \ldots, 100\) km. We can calculate the distance to the nearest station by checking the distances to the two closest water stations and selecting the one that is closer to \(N\).

Here's the step-by-step algorithm:

1. Calculate the index of the water station just before \(N\).
2. Calculate the index of the water station just after \(N\).
3. Determine the distance to the nearest station by comparing the distances to the two calculated stations.

Let's implement this in Python:

```python
# Read the input value N
N = int(input())

# Calculate the indices of the water stations just before and just after N
index_before = N // 5 * 5
index_after = index_before + 5

# Calculate the distances to these stations
distance_before = abs(N - index_before)
distance_after = abs(N - index_after)

# Determine the nearest water station
if distance_before <= distance_after:
    print(index_before)
else:
    print(index_after)
```

This code reads the input value \(N\) and calculates the distances to the nearest water stations. It then prints the distance to the nearest station.
````

### Extracted final code

````python
# Read the input value N
N = int(input())

# Calculate the indices of the water stations just before and just after N
index_before = N // 5 * 5
index_after = index_before + 5

# Calculate the distances to these stations
distance_before = abs(N - index_before)
distance_after = abs(N - index_after)

# Determine the nearest water station
if distance_before <= distance_after:
    print(index_before)
else:
    print(index_after)

````

### Test result

````json
null
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 10,
  "finish_reason": "stop",
  "prompt_tokens": 484,
  "completion_tokens": 210,
  "gen_seconds": 4.37,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
The problem involves finding the nearest water station to a given point on an ultramarathon course. Given that water stations are set up every 5 km, including the start and goal, the task is to find the distance to the nearest station from a given position \(N\). Since the stations are at 0, 5, 10, ..., 100 km, we can calculate the distance to the nearest station by comparing \(N\) with these points and their adjacent points.

The distance to the nearest station can be determined by checking the distance to the station at \(5k\) km (where \(k\) is an integer) and the station at \(5k \pm 5\) km. The station that is closest to \(N\) will be the desired answer.

### Complete Solution Code:
```python
N = int(input())
nearest_distance = min(abs(N - 5 * i) for i in range(21))
print(5 * (nearest_distance // 5))
```
````

### Extracted final code

````python
N = int(input())
nearest_distance = min(abs(N - 5 * i) for i in range(21))
print(5 * (nearest_distance // 5))

````

### Test result

````json
{
  "test_index": 0,
  "input": "53\n",
  "expected": "55\n",
  "got": "0\n",
  "error": null
}
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 10,
  "finish_reason": "stop",
  "prompt_tokens": 484,
  "completion_tokens": 238,
  "gen_seconds": 4.98,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves finding the nearest water station to a given position on a 100 km ultramarathon course, where water stations are set up every 5 km. Since Takahashi's position is \(N\), we need to determine the nearest multiple of 5 to \(N\).

Here's how we can solve it:
1. Calculate the nearest multiple of 5 to \(N\).
2. Determine the distance to the nearest water station by finding the minimum distance between \(N\) and the two closest multiples of 5.

Given \(N\), we can find the nearest water station by calculating the value of \(N\) modulo 5, and then determining the closest multiple of 5. If \(N\) is at a water station, the distance to the water station is 0.

Let's implement this logic.

```python
# Read the input value N
N = int(input())

# Calculate the nearest water station position
nearest_station = N - N % 5

# Calculate the distance to the nearest water station
distance = abs(N - nearest_station)

# Output the distance to the nearest water station
print(nearest_station)
```
````

### Extracted final code

````python
# Read the input value N
N = int(input())

# Calculate the nearest water station position
nearest_station = N - N % 5

# Calculate the distance to the nearest water station
distance = abs(N - nearest_station)

# Output the distance to the nearest water station
print(nearest_station)

````

### Test result

````json
{
  "test_index": 0,
  "input": "53\n",
  "expected": "55\n",
  "got": "50\n",
  "error": null
}
````
