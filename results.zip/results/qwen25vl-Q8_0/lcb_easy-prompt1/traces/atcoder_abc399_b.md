# atcoder_abc399_b — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "atcoder_abc399_b",
  "title": "Ranking with Ties",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2025-03-29",
  "format": "stdin",
  "prompt_style": 1,
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
N people labeled from 1 to N participated in a certain contest. The score of person i (1 \leq i \leq N) was P_i.
In this contest, the rank of each of the N people is determined by the following procedure:

- Prepare a variable r, and initialize r = 1. Initially, the ranks of the N people are all undetermined.
- Repeat the following operation until the ranks of all N people are determined:
- Let x be the maximum score among the people whose ranks are currently undetermined, and let k be the number of people whose score is x. Determine the rank of those k people with score x to be r, and then add k to r.



Print the rank of each of the N people.

Input

The input is given from Standard Input in the following format:
N
P_1 P_2 \dots P_N

Output

Print N lines. The i-th line (1 \leq i \leq N) should contain the rank of person i as an integer.

Constraints


- 1\leq N \leq 100
- 1\leq P_i \leq 100
- All input values are integers.

Sample Input 1

4
3 12 9 9

Sample Output 1

4
1
2
2

The ranks of the N\ (=4) people are determined as follows:

- Prepare a variable r and initialize r=1. At first, the ranks of all 4 people are undetermined.
- Currently, persons 1, 2, 3, 4 have undetermined ranks. The maximum score among them is P_2\ (=12). Therefore, determine the rank of person 2 to be r\ (=1), and then add 1 to r, making r=2.
- Currently, persons 1, 3, 4 have undetermined ranks. The maximum score among them is P_3=P_4\ (=9). Therefore, determine the ranks of persons 3 and 4 to be r\ (=2), and then add 2 to r, making r=4.
- Currently, person 1 has an undetermined rank. The maximum score among them is P_1\ (=3). Therefore, determine the rank of person 1 to be r\ (=4), and then add 1 to r, making r=5.
- The ranks of all 4 people are now determined, so the process ends.

Sample Input 2

3
3 9 6

Sample Output 2

3
1
2

Sample Input 3

4
100 100 100 100

Sample Output 3

1
1
1
1

Sample Input 4

8
87 87 87 88 41 38 41 38

Sample Output 4

2
2
2
1
5
7
5
7

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 807,
  "completion_tokens": 328,
  "gen_seconds": 7.37,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine the ranks of people based on their scores using a greedy algorithm. Here's the step-by-step approach:

1. **Initialize** a list to store the ranks and a dictionary to count the occurrences of each score.
2. **Populate** the dictionary with the scores from the input.
3. **Initialize** a variable to keep track of the current rank (`r`).
4. **Iterate** through the scores in descending order. For each score, determine the number of people with that score (`k`).
5. **Assign** the rank `r` to the `k` people with that score, and increment `r` by `k`.

Here's the complete solution:

```python
import sys

def main():
    input = sys.stdin.read
    data = input().split()
    N = int(data[0])
    people_scores = list(map(int, data[1:]))

    # Sort scores in descending order to prioritize higher scores
    people_scores.sort(reverse=True)

    # Initialize rank counter
    r, rank = 1, [0] * N

    # Loop through scores
    for score in people_scores:
        # Count the number of people with the current score
        k = people_scores.count(score)
        
        # Assign the rank to the people with the current score
        for i in range(k):
            rank[i] = r
        r += k

    # Print the ranks
    for i in range(N):
        print(rank[i])

if __name__ == "__main__":
    main()
```
````

### Extracted final code

````python
import sys

def main():
    input = sys.stdin.read
    data = input().split()
    N = int(data[0])
    people_scores = list(map(int, data[1:]))

    # Sort scores in descending order to prioritize higher scores
    people_scores.sort(reverse=True)

    # Initialize rank counter
    r, rank = 1, [0] * N

    # Loop through scores
    for score in people_scores:
        # Count the number of people with the current score
        k = people_scores.count(score)
        
        # Assign the rank to the people with the current score
        for i in range(k):
            rank[i] = r
        r += k

    # Print the ranks
    for i in range(N):
        print(rank[i])

if __name__ == "__main__":
    main()

````

### Test result

````json
{
  "test_index": 0,
  "input": "4\n3 12 9 9",
  "expected": "4\n1\n2\n2",
  "got": "6\n4\n0\n0\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 807,
  "completion_tokens": 173,
  "gen_seconds": 3.78,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
The problem involves assigning ranks to participants based on their scores. The ranking procedure iterates as follows:
1. Initialize a rank counter `r` to 1.
2. Identify the maximum score `x` among the participants with currently undetermined ranks.
3. Count the number of participants with score `x`.
4. Assign the rank `r` to these participants and increment `r` by the count of participants with score `x`.

This process repeats until all participants have a determined rank.

### Complete Solution:
```python
N = int(input())
scores = list(map(int, input().split()))

r = 1
while scores:
    max_score = max(scores)
    count = scores.count(max_score)
    for _ in range(count):
        print(r)
        scores.remove(max_score)
    r += count
```
````

### Extracted final code

````python
N = int(input())
scores = list(map(int, input().split()))

r = 1
while scores:
    max_score = max(scores)
    count = scores.count(max_score)
    for _ in range(count):
        print(r)
        scores.remove(max_score)
    r += count

````

### Test result

````json
{
  "test_index": 0,
  "input": "4\n3 12 9 9",
  "expected": "4\n1\n2\n2",
  "got": "1\n2\n2\n4\n",
  "error": null
}
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 807,
  "completion_tokens": 307,
  "gen_seconds": 6.69,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem involves ranking participants based on their scores. We need to repeatedly determine the rank of the highest-scoring undetermined participants and update the rank variable accordingly. Once all participants have been ranked, we print their respective ranks.

Here's how we can approach it:
1. Read the number of participants and their scores.
2. Sort the scores in descending order.
3. Initialize the rank variable.
4. Iterate through the sorted scores, assigning the current rank to participants with that score and updating the rank variable.
5. Print the ranks for each participant.

Let's implement this approach.
```python
# read the number of participants and their scores
n = int(input())
scores = list(map(int, input().split()))
# sort the scores in descending order
scores.sort(reverse=True)
# initialize the rank variable
rank = 1
# list to keep track of the rank for each participant
rank_list = [0] * n
# iterate through the sorted scores and assign ranks
for score in scores:
    # find the number of participants with the current score
    count = scores.count(score)
    # assign the current rank to the corresponding number of participants
    for _ in range(count):
        rank_list[scores.index(score)] = rank
        scores[scores.index(score)] = -1  # mark as assigned
    # update the rank variable
    rank += count
# print the ranks for each participant
for rank in rank_list:
    print(rank)
```
````

### Extracted final code

````python
# read the number of participants and their scores
n = int(input())
scores = list(map(int, input().split()))
# sort the scores in descending order
scores.sort(reverse=True)
# initialize the rank variable
rank = 1
# list to keep track of the rank for each participant
rank_list = [0] * n
# iterate through the sorted scores and assign ranks
for score in scores:
    # find the number of participants with the current score
    count = scores.count(score)
    # assign the current rank to the corresponding number of participants
    for _ in range(count):
        rank_list[scores.index(score)] = rank
        scores[scores.index(score)] = -1  # mark as assigned
    # update the rank variable
    rank += count
# print the ranks for each participant
for rank in rank_list:
    print(rank)

````

### Test result

````json
{
  "test_index": 0,
  "input": "4\n3 12 9 9",
  "expected": "4\n1\n2\n2",
  "got": "4\n2\n2\n7\n",
  "error": null
}
````
