# atcoder_abc304_b — PASS (1/3 attempts passed)

````json
{
  "id": "atcoder_abc304_b",
  "title": "Subscribers",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2023-06-03",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
You are given an integer N.
Print an approximation of N according to the following instructions.

- If N is less than or equal to 10^3-1, print N as it is.
- If N is between 10^3 and 10^4-1, inclusive, truncate the ones digit of N and print the result.
- If N is between 10^4 and 10^5-1, inclusive, truncate the tens digit and all digits below it of N and print the result.
- If N is between 10^5 and 10^6-1, inclusive, truncate the hundreds digit and all digits below it of N and print the result.
- If N is between 10^6 and 10^7-1, inclusive, truncate the thousands digit and all digits below it of N and print the result.
- If N is between 10^7 and 10^8-1, inclusive, truncate the ten-thousands digit and all digits below it of N and print the result.
- If N is between 10^8 and 10^9-1, inclusive, truncate the hundred-thousands digit and all digits below it of N and print the result.

Input

The input is given from Standard Input in the following format:
N

Output

Print the answer.

Constraints


- N is an integer between 0 and 10^9-1, inclusive.

Sample Input 1

20230603

Sample Output 1

20200000

20230603 is between 10^7 and 10^8-1 (inclusive).
Therefore, truncate the ten-thousands digit and all digits below it, and print 20200000.

Sample Input 2

0

Sample Output 2

0

Sample Input 3

304

Sample Output 3

304

Sample Input 4

500600

Sample Output 4

500000

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 614,
  "completion_tokens": 406,
  "gen_seconds": 8.8,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem requires us to approximate a number `N` based on its range. We'll use conditional statements to determine the appropriate truncation based on the size of `N`. For each range, we'll truncate the respective digits and print the result.

The ranges are:
- Numbers less than or equal to 10^3-1: Print `N` as is.
- Numbers between 10^3 and 10^4-1: Truncate the ones digit.
- Numbers between 10^4 and 10^5-1: Truncate the tens digit.
- Numbers between 10^5 and 10^6-1: Truncate the hundreds digit.
- Numbers between 10^6 and 10^7-1: Truncate the thousands digit.
- Numbers between 10^7 and 10^8-1: Truncate the ten-thousands digit.
- Numbers between 10^8 and 10^9-1: Truncate the hundred-thousands digit.

We can do this by converting `N` to a string, manipulating the string, and then converting it back to an integer to print.

```python
N = int(input())
if N <= 10**3 - 1:
    print(N)
elif N <= 10**4 - 1:
    print(N // 10)
elif N <= 10**5 - 1:
    print(N // 100)
elif N <= 10**6 - 1:
    print(N // 1000)
elif N <= 10**7 - 1:
    print(N // 10000)
elif N <= 10**8 - 1:
    print(N // 100000)
elif N <= 10**9 - 1:
    print(N // 1000000)
```
````

### Extracted final code

````python
N = int(input())
if N <= 10**3 - 1:
    print(N)
elif N <= 10**4 - 1:
    print(N // 10)
elif N <= 10**5 - 1:
    print(N // 100)
elif N <= 10**6 - 1:
    print(N // 1000)
elif N <= 10**7 - 1:
    print(N // 10000)
elif N <= 10**8 - 1:
    print(N // 100000)
elif N <= 10**9 - 1:
    print(N // 1000000)

````

### Test result

````json
{
  "test_index": 0,
  "input": "20230603\n",
  "expected": "20200000\n",
  "got": "202\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 13,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 614,
  "completion_tokens": 195,
  "gen_seconds": 4.18,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
```python
number = int(input())
if number >= 10**7 and number <= 10**8 - 1:
    print(number // 100000 * 100000)
elif number >= 10**6 and number <= 10**7 - 1:
    print(number // 10000 * 10000)
elif number >= 10**5 and number <= 10**6 - 1:
    print(number // 1000 * 1000)
elif number >= 10**4 and number <= 10**5 - 1:
    print(number // 100 * 100)
elif number >= 10**3 and number <= 10**4 - 1:
    print(number // 10 * 10)
else:
    print(number)
```
````

### Extracted final code

````python
number = int(input())
if number >= 10**7 and number <= 10**8 - 1:
    print(number // 100000 * 100000)
elif number >= 10**6 and number <= 10**7 - 1:
    print(number // 10000 * 10000)
elif number >= 10**5 and number <= 10**6 - 1:
    print(number // 1000 * 1000)
elif number >= 10**4 and number <= 10**5 - 1:
    print(number // 100 * 100)
elif number >= 10**3 and number <= 10**4 - 1:
    print(number // 10 * 10)
else:
    print(number)

````

### Test result

````json
{
  "test_index": 13,
  "input": "999999999\n",
  "expected": "999000000\n",
  "got": "999999999\n",
  "error": null
}
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 16,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 614,
  "completion_tokens": 486,
  "gen_seconds": 10.34,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem requires us to truncate parts of the number `N` based on its range. We can achieve this by determining the range of `N` and then truncating the appropriate digits. Specifically, we need to check the length of `N` to determine the digit we should truncate.

Here’s the plan:
1. Convert `N` to a string to easily access its digits.
2. Determine the range of `N`.
3. Based on the range, truncate the appropriate digits from `N`.
4. Print the truncated `N`.

The ranges given are:
- 0 to 999: No truncation needed.
- 1000 to 9999: Truncate the last digit.
- 10000 to 99999: Truncate the second last digit.
- 100000 to 999999: Truncate the third last digit.
- 1000000 to 9999999: Truncate the fourth last digit.
- 10000000 to 99999999: Truncate the fifth last digit.
- 100000000 to 999999999: Truncate the sixth last digit.

We can implement this by using the length of the string representation of `N` to decide on the digit to truncate.
```python
N = int(input())

if N <= 999:
    print(N)
elif N <= 9999:
    print(N // 10 * 10)
elif N <= 99999:
    print(N // 100 * 100)
elif N <= 999999:
    print(N // 1000 * 1000)
elif N <= 9999999:
    print(N // 10000 * 10000)
elif N <= 99999999:
    print(N // 100000 * 100000)
else:
    print(N // 1000000 * 1000000)
```
````

### Extracted final code

````python
N = int(input())

if N <= 999:
    print(N)
elif N <= 9999:
    print(N // 10 * 10)
elif N <= 99999:
    print(N // 100 * 100)
elif N <= 999999:
    print(N // 1000 * 1000)
elif N <= 9999999:
    print(N // 10000 * 10000)
elif N <= 99999999:
    print(N // 100000 * 100000)
else:
    print(N // 1000000 * 1000000)

````

### Test result

````json
null
````
