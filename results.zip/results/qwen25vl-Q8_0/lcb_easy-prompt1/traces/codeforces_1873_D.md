# codeforces_1873_D — PASS (1/3 attempts passed)

````json
{
  "id": "codeforces_1873_D",
  "title": "D. 1D Eraser",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "codeforces",
  "difficulty": "easy",
  "contest_date": "2023-08-21",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
You are given a strip of paper $s$ that is $n$ cells long. Each cell is either black or white. In an operation you can take any $k$ consecutive cells and make them all white.

Find the minimum number of operations needed to remove all black cells.

Input

The first line contains a single integer $t$ ($1 \leq t \leq 1000$) — the number of test cases.

The first line of each test case contains two integers $n$ and $k$ ($1 \leq k \leq n \leq 2 \cdot 10^5$) — the length of the paper and the integer used in the operation.

The second line of each test case contains a string $s$ of length $n$ consisting of characters $\texttt{B}$ (representing a black cell) or $\texttt{W}$ (representing a white cell).

The sum of $n$ over all test cases does not exceed $2 \cdot 10^5$.

Output

For each test case, output a single integer — the minimum number of operations needed to remove all black cells.Sample Input 1:
8

6 3

WBWWWB

7 3

WWBWBWW

5 4

BWBWB

5 5

BBBBB

8 2

BWBWBBBB

10 2

WBBWBBWBBW

4 1

BBBB

3 2

WWW



Sample Output 1:

2
1
2
1
4
3
4
0


Note

In the first test case you can perform the following operations: $$\color{red}{\texttt{WBW}}\texttt{WWB} \to \texttt{WWW}\color{red}{\texttt{WWB}} \to \texttt{WWWWWW}$$

In the second test case you can perform the following operations: $$\texttt{WW}\color{red}{\texttt{BWB}}\texttt{WW} \to \texttt{WWWWWWW}$$

In the third test case you can perform the following operations: $$\texttt{B}\color{red}{\texttt{WBWB}} \to \color{red}{\texttt{BWWW}}\texttt{W} \to \texttt{WWWWW}$$

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 686,
  "completion_tokens": 365,
  "gen_seconds": 8.12,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine the minimum number of operations required to turn all black cells (represented by 'B') into white cells (represented by 'W') in a strip of paper of length `n` with an operation that can make `k` consecutive cells white. Here's a step-by-step algorithm:

1. **Initialization**: Read the number of test cases `t`. For each test case, read `n` (the length of the strip) and `k` (the number of consecutive cells that can be turned white). Read the string `s` representing the strip.

2. **Counting Operations**: For each segment of `k` cells in the string, if there is at least one 'B', we need to perform an operation to turn the segment white. The number of operations needed is the number of 'B's in each segment of `k` cells.

3. **Efficient Calculation**: To avoid counting each segment individually, we can use a sliding window approach to count the number of 'B's that need to be removed in each segment, and then calculate the total number of operations needed.

Let's implement this algorithm:

```python
def min_operations(n, k, s):
    operations = 0
    for i in range(0, n - k + 1, k):
        if 'B' in s[i:i+k]:
            operations += s[i:i+k].count('B')
    return operations

t = int(input())
for _ in range(t):
    n, k = map(int, input().split())
    s = input()
    print(min_operations(n, k, s))
```

This code reads the input, processes each test case, and prints the minimum number of operations needed to turn all black cells white.
````

### Extracted final code

````python
def min_operations(n, k, s):
    operations = 0
    for i in range(0, n - k + 1, k):
        if 'B' in s[i:i+k]:
            operations += s[i:i+k].count('B')
    return operations

t = int(input())
for _ in range(t):
    n, k = map(int, input().split())
    s = input()
    print(min_operations(n, k, s))

````

### Test result

````json
{
  "test_index": 0,
  "input": "8\n6 3\nWBWWWB\n7 3\nWWBWBWW\n5 4\nBWBWB\n5 5\nBBBBB\n8 2\nBWBWBBBB\n10 2\nWBBWBBWBBW\n4 1\nBBBB\n3 2\nWWW\n",
  "expected": "2\n1\n2\n1\n4\n3\n4\n0\n",
  "got": "2\n2\n2\n5\n6\n6\n4\n0\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 686,
  "completion_tokens": 211,
  "gen_seconds": 4.55,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To solve this problem, we need to determine the minimum number of operations required to convert a strip of paper into a configuration where all cells are white. The operation allows us to change any \( k \) consecutive cells to white. Here’s the approach:

1. **Count Black Cells**: Count the number of black cells in the strip.
2. **Operation Impact**: Each operation can clear \( k \) black cells. Therefore, the minimum number of operations required is the ceiling of the total number of black cells divided by \( k \).

This method ensures that we use the least number of operations to achieve the goal. We can implement this by iterating through the input, counting black cells, and calculating the result.

### Complete Solution:
```python
for _ in range(int(input())):
    n, k = map(int, input().split())
    s = input()
    black_count = s.count('B')
    operations = -(-black_count // k)  # ceiling division
    print(operations)
```
````

### Extracted final code

````python
for _ in range(int(input())):
    n, k = map(int, input().split())
    s = input()
    black_count = s.count('B')
    operations = -(-black_count // k)  # ceiling division
    print(operations)

````

### Test result

````json
{
  "test_index": 0,
  "input": "8\n6 3\nWBWWWB\n7 3\nWWBWBWW\n5 4\nBWBWB\n5 5\nBBBBB\n8 2\nBWBWBBBB\n10 2\nWBBWBBWBBW\n4 1\nBBBB\n3 2\nWWW\n",
  "expected": "2\n1\n2\n1\n4\n3\n4\n0\n",
  "got": "1\n1\n1\n1\n3\n3\n4\n0\n",
  "error": null
}
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 13,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 686,
  "completion_tokens": 253,
  "gen_seconds": 5.48,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves determining the minimum number of operations needed to transform a strip of paper into a completely white strip. An operation consists of changing any \(k\) consecutive cells to white. Given the constraints, the solution relies on finding the minimum number of operations required to convert the input string into all whites.

Here's a brief outline of the algorithm:
1. Iterate through the input string.
2. For each black cell (represented by 'B'), determine how many operations are needed to clear it and its \(k-1\) neighbors to the right.
3. Accumulate the total count of operations.

Now, let's implement this in code.

```python
def min_operations(n, k, s):
    operations = 0
    for i in range(n):
        if s[i] == 'B':
            operations += 1
            # Clear the current 'B' and its k-1 neighbors to the right
            s = s[:i] + 'W' * k + s[i+k:]
    return operations

t = int(input())
for _ in range(t):
    n, k = map(int, input().split())
    s = input()
    result = min_operations(n, k, s)
    print(result)
```
````

### Extracted final code

````python
def min_operations(n, k, s):
    operations = 0
    for i in range(n):
        if s[i] == 'B':
            operations += 1
            # Clear the current 'B' and its k-1 neighbors to the right
            s = s[:i] + 'W' * k + s[i+k:]
    return operations

t = int(input())
for _ in range(t):
    n, k = map(int, input().split())
    s = input()
    result = min_operations(n, k, s)
    print(result)

````

### Test result

````json
null
````
