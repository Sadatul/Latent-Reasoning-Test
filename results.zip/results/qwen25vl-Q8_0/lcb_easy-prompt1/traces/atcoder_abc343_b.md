# atcoder_abc343_b — PASS (1/3 attempts passed)

````json
{
  "id": "atcoder_abc343_b",
  "title": "Adjacency Matrix",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-03-02",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
There is a simple undirected graph G with N vertices labeled with numbers 1, 2, \ldots, N.
You are given the adjacency matrix (A_{i,j}) of G. That is, G has an edge connecting vertices i and j if and only if A_{i,j} = 1.
For each i = 1, 2, \ldots, N, print the numbers of the vertices directly connected to vertex i in ascending order.
Here, vertices i and j are said to be directly connected if and only if there is an edge connecting vertices i and j.

Input

The input is given from Standard Input in the following format:
N
A_{1,1} A_{1,2} \ldots A_{1,N}
A_{2,1} A_{2,2} \ldots A_{2,N}
\vdots
A_{N,1} A_{N,2} \ldots A_{N,N}

Output

Print N lines.
The i-th line should contain the numbers of the vertices directly connected to vertex i in ascending order, separated by a space.

Constraints


- 2 \leq N \leq 100
- A_{i,j} \in \lbrace 0,1 \rbrace
- A_{i,i} = 0
- A_{i,j} = A_{j,i}
- All input values are integers.

Sample Input 1

4
0 1 1 0
1 0 0 1
1 0 0 0
0 1 0 0

Sample Output 1

2 3
1 4
1
2

Vertex 1 is directly connected to vertices 2 and 3. Thus, the first line should contain 2 and 3 in this order.
Similarly, the second line should contain 1 and 4 in this order, the third line should contain 1, and the fourth line should contain 2.

Sample Input 2

2
0 0
0 0

Sample Output 2





G may have no edges.

Sample Input 3

5
0 1 0 1 1
1 0 0 1 0
0 0 0 0 1
1 1 0 0 1
1 0 1 1 0

Sample Output 3

2 4 5
1 4
5
1 2 5
1 3 4

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 15,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 703,
  "completion_tokens": 216,
  "gen_seconds": 5.0,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem requires reading an adjacency matrix of a graph and printing the vertices directly connected to each vertex in ascending order. We can achieve this by iterating through the adjacency matrix to find the connected vertices for each vertex.

To solve this, we will:
1. Read the number of vertices `N` and the adjacency matrix.
2. For each vertex `i`, use the `i-th` row of the adjacency matrix to collect the indices of the connected vertices.
3. Print the connected vertices of each vertex in ascending order.

Let's implement this approach.
```python
# Read the number of vertices and the adjacency matrix
N = int(input())
adj_matrix = [list(map(int, input().split())) for _ in range(N)]

# Iterate through each vertex to find connected vertices
for i in range(N):
    # Collect indices of connected vertices
    connected_vertices = [j + 1 for j in range(N) if adj_matrix[i][j] == 1]
    # Sort and print the connected vertices
    print(*sorted(connected_vertices))
```
````

### Extracted final code

````python
# Read the number of vertices and the adjacency matrix
N = int(input())
adj_matrix = [list(map(int, input().split())) for _ in range(N)]

# Iterate through each vertex to find connected vertices
for i in range(N):
    # Collect indices of connected vertices
    connected_vertices = [j + 1 for j in range(N) if adj_matrix[i][j] == 1]
    # Sort and print the connected vertices
    print(*sorted(connected_vertices))

````

### Test result

````json
null
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 703,
  "completion_tokens": 203,
  "gen_seconds": 4.51,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
The problem requires processing an adjacency matrix to find and print the indices of vertices directly connected to each vertex in the graph. Here's the plan:
1. Read the number of vertices `N` and the adjacency matrix from the input.
2. For each vertex `i` from `1` to `N`, find all vertices `j` such that `A_{i,j} = 1`.
3. Print the indices of these vertices in ascending order for each `i`.

### Complete Solution:
```python
# Read the number of vertices
N = int(input())

# Initialize the adjacency matrix A
A = [list(map(int, input().split())) for _ in range(N)]

# Process each vertex
for i in range(N):
    # Find indices of connected vertices
    connected = [j for j in range(N) if A[i][j] == 1]
    # Print the connected vertices in ascending order
    print(*sorted(connected))
```
````

### Extracted final code

````python
# Read the number of vertices
N = int(input())

# Initialize the adjacency matrix A
A = [list(map(int, input().split())) for _ in range(N)]

# Process each vertex
for i in range(N):
    # Find indices of connected vertices
    connected = [j for j in range(N) if A[i][j] == 1]
    # Print the connected vertices in ascending order
    print(*sorted(connected))

````

### Test result

````json
{
  "test_index": 0,
  "input": "4\n0 1 1 0\n1 0 0 1\n1 0 0 0\n0 1 0 0\n",
  "expected": "2 3\n1 4\n1\n2\n",
  "got": "1 2\n0 3\n0\n1\n",
  "error": null
}
````

## Attempt 3 — RUNTIME_ERROR

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "runtime_error",
  "num_passed": 0,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 703,
  "completion_tokens": 172,
  "gen_seconds": 3.83,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem requires us to process an adjacency matrix of a simple undirected graph and print the directly connected vertices for each vertex in ascending order. Here's the approach:

1. Read the number of vertices `N` and the adjacency matrix `A`.
2. For each vertex `i` from 1 to `N`, determine its directly connected vertices by looking at the `i-th` row of the adjacency matrix.
3. Collect these vertices and sort them in ascending order.
4. Print the sorted list of vertices for each vertex `i`.

The adjacency matrix `A` is a square matrix where `A[i][j] = 1` indicates an edge between vertices `i` and `j`, and `A[i][i] = 0` for all `i`.
```python
<complete solution code>
```
````

### Extracted final code

````python
<complete solution code>

````

### Test result

````json
{
  "test_index": 0,
  "input": "4\n0 1 1 0\n1 0 0 1\n1 0 0 0\n0 1 0 0\n",
  "expected": "2 3\n1 4\n1\n2\n",
  "got": "",
  "error": "  File \"/tmp/eval_lg276opb/solution.py\", line 26\n    <complete solution code>\n    ^\nSyntaxError: invalid syntax\n"
}
````
