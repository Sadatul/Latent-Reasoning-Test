# atcoder_abc321_b — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "atcoder_abc321_b",
  "title": "Cutoff",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2023-09-23",
  "format": "stdin",
  "prompt_style": 1,
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
There is an exam structured as follows.

- The exam consists of N rounds called round 1 to N.
- In each round, you are given an integer score between 0 and 100, inclusive.
- Your final grade is the sum of the N-2 of the scores earned in the rounds excluding the highest and lowest.
- Formally, let S=(S_1,S_2,\dots,S_N) be the sequence of the scores earned in the rounds sorted in ascending order, then the final grade is S_2+S_3+\dots+S_{N-1}.



Now, N-1 rounds of the exam have ended, and your score in round i was A_i.
Print the minimum score you must earn in round N for a final grade of X or higher.
If your final grade will never be X or higher no matter what score you earn in round N, print -1 instead.
Note that your score in round N can only be an integer between 0 and 100.

Input

The input is given from Standard Input in the following format:
N X
A_1 A_2 \dots A_{N-1}

Output

Print the answer.

Constraints


- All input values are integers.
- 3 \le N \le 100
- 0 \le X \le 100 \times (N-2)
- 0 \le A_i \le 100

Sample Input 1

5 180
40 60 80 50

Sample Output 1

70

Your scores in the first four rounds were 40, 60, 80, and 50.
If you earn a score of 70 in round 5, the sequence of the scores sorted in ascending order will be S=(40,50,60,70,80), for a final grade of 50+60+70=180.
It can be shown that 70 is the minimum score you must earn for a final grade of 180 or higher.

Sample Input 2

3 100
100 100

Sample Output 2

0

Your scores in the first two rounds were 100 and 100.
If you earn a score of 0 in round 3, the sequence of the scores sorted in ascending order will be S=(0,100,100), for a final grade of 100.
Note that the highest score, 100, is earned multiple times, and only one of them is excluded. (The same goes for the lowest score.)
It can be shown that 0 is the minimum score you must earn for a final grade of 100 or higher.

Sample Input 3

5 200
0 0 99 99

Sample Output 3

-1

Your scores in the first four rounds were 0, 0, 99, and 99.
It can be shown that your final grade will never be 200 or higher no matter what score you earn in round 5.

Sample Input 4

10 480
59 98 88 54 70 24 8 94 46

Sample Output 4

45

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 894,
  "completion_tokens": 442,
  "gen_seconds": 9.64,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine the minimum score required in the final round (round N) to achieve a specific final grade.

1. **Sort the scores**: We first sort the scores in ascending order.
2. **Calculate the required sum**: To achieve the desired final grade, we need to sum up `N-2` scores excluding the highest and the lowest scores.
3. **Find the minimum score**: For each possible score in the final round, we check if the sum of the required scores plus the score in the final round reaches or exceeds the desired final grade.
4. **Check constraints**: Ensure the score in the final round is between 0 and 100.

Given the constraints and the specific requirements, let's implement the solution:

```python
from sys import stdin
n, x = map(int, stdin.readline().split())
scores = list(map(int, stdin.readline().split()))

# Sort the scores
scores.sort()

# Calculate the required sum excluding the highest and lowest scores
required_sum = sum(scores[1:-1])

# Check if a valid score exists
if required_sum + scores[-1] >= x:
    print(max(0, x - required_sum))
else:
    print(-1)
```

This code first reads the number of rounds `n`, the desired final grade `x`, and the scores from the previous rounds. It sorts the scores and calculates the required sum of the remaining scores excluding the highest and lowest. It then checks if adding the highest possible score in the final round would meet or exceed the desired final grade. If so, it calculates the minimum score required; otherwise, it prints -1.
```python

```python
from sys import stdin
n, x = map(int, stdin.readline().split())
scores = list(map(int, stdin.readline().split()))

# Sort the scores
scores.sort()

# Calculate the required sum excluding the highest and lowest scores
required_sum = sum(scores[1:-1])

# Check if a valid score exists
if required_sum + scores[-1] >= x:
    print(max(0, x - required_sum))
else:
    print(-1)
```
````

### Extracted final code

````python


````

### Test result

````json
{
  "test_index": 0,
  "input": "5 180\n40 60 80 50\n",
  "expected": "70\n",
  "got": "",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 894,
  "completion_tokens": 237,
  "gen_seconds": 5.04,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
1. **Sorting Scores**: To calculate the minimum score needed in round \( N \) to achieve a final grade of \( X \), we first need to sort the scores from the first \( N-1 \) rounds in ascending order.
2. **Removing Extremes**: We remove the highest and lowest scores from the sorted list.
3. **Summing Remaining Scores**: The sum of the remaining scores should be equal to or greater than \( X \).
4. **Calculating Needed Score**: To find the minimum score for round \( N \), we sum the removed highest and lowest scores and subtract this from \( X \).

### Complete Solution:
```python
N, X = map(int, input().split())
A = list(map(int, input().split()))
A.sort()

# Find the minimum score needed in round N
score_needed = X - (A[0] + A[-1])

# Check if the score needed is within the valid range (0 to 100)
if score_needed >= 0 and score_needed <= 100:
    print(score_needed)
else:
    print(-1)
```
````

### Extracted final code

````python
N, X = map(int, input().split())
A = list(map(int, input().split()))
A.sort()

# Find the minimum score needed in round N
score_needed = X - (A[0] + A[-1])

# Check if the score needed is within the valid range (0 to 100)
if score_needed >= 0 and score_needed <= 100:
    print(score_needed)
else:
    print(-1)

````

### Test result

````json
{
  "test_index": 0,
  "input": "5 180\n40 60 80 50\n",
  "expected": "70\n",
  "got": "60\n",
  "error": null
}
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 894,
  "completion_tokens": 467,
  "gen_seconds": 9.93,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves calculating the minimum score required in the final round to achieve a specific final grade, ensuring the highest and lowest scores are excluded from the sum. To solve this, we'll first sort the scores, excluding the two extremes, and then calculate the minimum score needed in the final round.

Here's the step-by-step approach:

1. Read the input values for \(N\) and \(X\), and the scores \(A_1, A_2, \dots, A_{N-1}\).
2. Sort the scores excluding the highest and lowest.
3. Calculate the sum of the sorted scores.
4. Determine the minimum score needed in the final round to reach the target final grade \(X\).
5. If the final grade can never reach \(X\), return -1.

Let's implement this logic in Python:

```python
# Read input
N, X = map(int, input().split())
scores = list(map(int, input().split()))

# Sort scores excluding the highest and lowest
sorted_scores = sorted(scores[1:-1])

# Calculate the sum of the sorted scores excluding the highest and lowest
sum_sorted_scores = sum(sorted_scores)

# Determine the minimum score needed in the final round
if sum_sorted_scores + scores[0] >= X:
    print(max(0, X - sum_sorted_scores - scores[-1]))
else:
    print(-1)
```

This code first reads the input values and scores, then calculates the sum of the sorted scores excluding the highest and lowest. It checks if the sum plus the lowest score is enough to reach the target grade and prints the minimum score needed in the final round, or -1 if it's not possible.
```python

```python
# Read input
N, X = map(int, input().split())
scores = list(map(int, input().split()))

# Sort scores excluding the highest and lowest
sorted_scores = sorted(scores[1:-1])

# Calculate the sum of the sorted scores excluding the highest and lowest
sum_sorted_scores = sum(sorted_scores)

# Determine the minimum score needed in the final round
if sum_sorted_scores + scores[0] >= X:
    print(max(0, X - sum_sorted_scores - scores[-1]))
else:
    print(-1)
```
````

### Extracted final code

````python


````

### Test result

````json
{
  "test_index": 0,
  "input": "5 180\n40 60 80 50\n",
  "expected": "70\n",
  "got": "",
  "error": null
}
````
