# atcoder_abc381_b — PASS (1/3 attempts passed)

````json
{
  "id": "atcoder_abc381_b",
  "title": "1122 String",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-11-22",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
A string T is called a 1122 string if and only if it satisfies all of the following three conditions:

- \lvert T \rvert is even. Here, \lvert T \rvert denotes the length of T.
- For each integer i satisfying 1\leq i\leq \frac{|T|}{2}, the (2i-1)-th and 2i-th characters of T are equal.
- Each character appears in T exactly zero or two times. That is, every character contained in T appears exactly twice in T.

Given a string S consisting of lowercase English letters, print Yes if S is a 1122 string, and No otherwise.

Input

The input is given from Standard Input in the following format:
S

Output

If S is a 1122 string, print Yes; otherwise, print No.

Constraints


- S is a string of length between 1 and 100, inclusive, consisting of lowercase English letters.

Sample Input 1

aabbcc

Sample Output 1

Yes

S=aabbcc satisfies all the conditions for a 1122 string, so print Yes.

Sample Input 2

aab

Sample Output 2

No

S=aab has an odd length and does not satisfy the first condition, so print No.

Sample Input 3

zzzzzz

Sample Output 3

No

S=zzzzzz contains six zs and does not satisfy the third condition, so print No.

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 488,
  "completion_tokens": 287,
  "gen_seconds": 6.43,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if the given string `S` meets all the criteria of a 1122 string. Here's the step-by-step approach:

1. **Length Check**: Ensure the length of `S` is even.
2. **Pairwise Equality Check**: Verify that each pair of characters at positions `(2i-1)` and `2i` are equal for `i` ranging from 1 to half the length of `S`.
3. **Character Frequency Check**: Ensure each character appears exactly zero or two times in `S`.

Let's implement this in Python:

```python
s = input().strip()
n = len(s)

# Check if length is even
if n % 2 == 1:
    print("No")
    exit(0)

# Check pairwise equality
for i in range(1, n // 2 + 1):
    if s[2 * i - 1] != s[2 * i]:
        print("No")
        exit(0)

# Check character frequency
char_count = {}
for char in s:
    if char in char_count:
        char_count[char] += 1
    else:
        char_count[char] = 1

for count in char_count.values():
    if count % 2 != 0:
        print("No")
        exit(0)

print("Yes")
```
````

### Extracted final code

````python
s = input().strip()
n = len(s)

# Check if length is even
if n % 2 == 1:
    print("No")
    exit(0)

# Check pairwise equality
for i in range(1, n // 2 + 1):
    if s[2 * i - 1] != s[2 * i]:
        print("No")
        exit(0)

# Check character frequency
char_count = {}
for char in s:
    if char in char_count:
        char_count[char] += 1
    else:
        char_count[char] = 1

for count in char_count.values():
    if count % 2 != 0:
        print("No")
        exit(0)

print("Yes")

````

### Test result

````json
{
  "test_index": 0,
  "input": "aabbcc",
  "expected": "Yes",
  "got": "No\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 2,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 488,
  "completion_tokens": 291,
  "gen_seconds": 6.41,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
1. **Condition 1**: The length of the string must be even.
2. **Condition 2**: The characters at positions 1, 3, 5, etc., and 2, 4, 6, etc., must be identical.
3. **Condition 3**: Each character in the string must appear exactly zero or two times.

To solve this, we can:
- Check if the length of the string is even.
- Verify the second condition by comparing characters at even and odd positions.
- Check the third condition by ensuring each character appears an even number of times.

### Complete Solution Code:
```python
import sys
input = sys.stdin.readline

def is_1122_string(s):
    n = len(s)
    if n % 2 != 0:
        return "No"
    
    for i in range(1, n, 2):
        if s[i] != s[i-1]:
            return "No"
    
    char_count = {}
    for c in s:
        if c in char_count:
            char_count[c] += 1
        else:
            char_count[c] = 1
    
    for count in char_count.values():
        if count % 2 != 0:
            return "No"
    
    return "Yes"

s = input().strip()
print(is_1122_string(s))
```
````

### Extracted final code

````python
import sys
input = sys.stdin.readline

def is_1122_string(s):
    n = len(s)
    if n % 2 != 0:
        return "No"
    
    for i in range(1, n, 2):
        if s[i] != s[i-1]:
            return "No"
    
    char_count = {}
    for c in s:
        if c in char_count:
            char_count[c] += 1
        else:
            char_count[c] = 1
    
    for count in char_count.values():
        if count % 2 != 0:
            return "No"
    
    return "Yes"

s = input().strip()
print(is_1122_string(s))

````

### Test result

````json
{
  "test_index": 2,
  "input": "zzzzzz",
  "expected": "No",
  "got": "Yes\n",
  "error": null
}
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 43,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 488,
  "completion_tokens": 284,
  "gen_seconds": 6.26,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The solution involves checking if the given string `S` meets the criteria for a 1122 string. We need to ensure that the string's length is even, every pair of characters are equal, and each character appears exactly twice in the string.

Let's break down the steps:

1. Check if the length of `S` is even.
2. Iterate over the string in steps of 2 (from the first character to the length of `S` minus the second character).
3. Verify that the characters at positions `2*i-1` and `2*i` are the same.
4. Count the frequency of each character and ensure no character appears more than twice.

Here is the implementation of the above logic:

```python
import collections

# Read the input
S = input()

# Check if the length of S is even
if len(S) % 2 != 0:
    print("No")
    exit()

# Check if each pair of characters are equal
for i in range(1, len(S), 2):
    if S[i-1] != S[i]:
        print("No")
        exit()

# Check the character frequency
freq = collections.Counter(S)

# Ensure no character appears more than twice
for char, count in freq.items():
    if count > 2:
        print("No")
        exit()

print("Yes")
```
````

### Extracted final code

````python
import collections

# Read the input
S = input()

# Check if the length of S is even
if len(S) % 2 != 0:
    print("No")
    exit()

# Check if each pair of characters are equal
for i in range(1, len(S), 2):
    if S[i-1] != S[i]:
        print("No")
        exit()

# Check the character frequency
freq = collections.Counter(S)

# Ensure no character appears more than twice
for char, count in freq.items():
    if count > 2:
        print("No")
        exit()

print("Yes")

````

### Test result

````json
null
````
