# atcoder_abc380_a — PASS (2/3 attempts passed)

````json
{
  "id": "atcoder_abc380_a",
  "title": "123233",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-11-16",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 2
}
````

## User prompt

````text
### Question:
You are given a 6-digit positive integer N.
Determine whether N satisfies all of the following conditions.

- Among the digits of N, the digit 1 appears exactly once.
- Among the digits of N, the digit 2 appears exactly twice.
- Among the digits of N, the digit 3 appears exactly three times.

Input

The input is given from Standard Input in the following format:
N

Output

Print Yes if N satisfies all the conditions described in the problem statement, and No otherwise, in one line.

Constraints


- N is an integer satisfying 100000 \le N \le 999999.

Sample Input 1

123233

Sample Output 1

Yes

123233 satisfies the conditions in the problem statement, so print Yes.

Sample Input 2

123234

Sample Output 2

No

123234 does not satisfy the conditions in the problem statement, so print No.

Sample Input 3

323132

Sample Output 3

Yes

Sample Input 4

500000

Sample Output 4

No

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — RUNTIME_ERROR

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "runtime_error",
  "num_passed": 0,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 423,
  "completion_tokens": 314,
  "gen_seconds": 6.91,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if the given 6-digit number `N` satisfies the following conditions:
1. The digit 1 appears exactly once.
2. The digit 2 appears exactly twice.
3. The digit 3 appears exactly three times.

Given that the number is 6 digits long, the only digits it can contain are 1, 2, and 3 (since no other digits exist within the constraints of the problem).

Here's the step-by-step approach:
1. Convert the number `N` to a string to easily iterate over its digits.
2. Count the occurrences of each digit (1, 2, 3) using a dictionary.
3. Check if the counts match the required occurrences: 1 appears exactly once, 2 appears exactly twice, and 3 appears exactly three times.

Let's implement this logic in Python:

```python
input()
n_str = input()
digit_count = {'1': 0, '2': 0, '3': 0}

for digit in n_str:
    digit_count[digit] += 1

if digit_count['1'] == 1 and digit_count['2'] == 2 and digit_count['3'] == 3:
    print("Yes")
else:
    print("No")
```

This solution reads the input number as a string, counts the occurrences of digits '1', '2', and '3', and prints "Yes" if the counts match the required occurrences, otherwise, it prints "No".
````

### Extracted final code

````python
input()
n_str = input()
digit_count = {'1': 0, '2': 0, '3': 0}

for digit in n_str:
    digit_count[digit] += 1

if digit_count['1'] == 1 and digit_count['2'] == 2 and digit_count['3'] == 3:
    print("Yes")
else:
    print("No")

````

### Test result

````json
{
  "test_index": 0,
  "input": "123233",
  "expected": "Yes",
  "got": "",
  "error": "Traceback (most recent call last):\n  File \"/tmp/eval_2n2msfft/solution.py\", line 27, in <module>\n    n_str = input()\nEOFError: EOF when reading a line\n"
}
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 423,
  "completion_tokens": 221,
  "gen_seconds": 4.84,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To solve this problem, we need to check if the given 6-digit number \(N\) satisfies the following conditions:
1. The digit 1 appears exactly once in \(N\).
2. The digit 2 appears exactly twice in \(N\).
3. The digit 3 appears exactly three times in \(N\).

We can achieve this by counting the occurrences of each digit in the number \(N\). If the counts match the specified conditions, we print "Yes"; otherwise, we print "No".

### Complete Solution Code:
```python
N = int(input())
count = [0] * 10  # Initialize a list to count occurrences of each digit from 0 to 9

# Count the occurrences of each digit in the number N
for digit in str(N):
    count[int(digit)] += 1

# Check the conditions
if count[1] == 1 and count[2] == 2 and count[3] == 3:
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
N = int(input())
count = [0] * 10  # Initialize a list to count occurrences of each digit from 0 to 9

# Count the occurrences of each digit in the number N
for digit in str(N):
    count[int(digit)] += 1

# Check the conditions
if count[1] == 1 and count[2] == 2 and count[3] == 3:
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 423,
  "completion_tokens": 182,
  "gen_seconds": 4.04,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem requires us to check if a given 6-digit number `N` meets three specific criteria:
1. The digit 1 appears exactly once.
2. The digit 2 appears exactly twice.
3. The digit 3 appears exactly three times.

We can solve this by counting the occurrences of each digit in the number `N` and verifying the counts against the required criteria.

Let's proceed with the solution.
```python
from collections import Counter

def check_conditions(N):
    digit_count = Counter(str(N))
    conditions_met = (digit_count['1'] == 1 and 
                      digit_count['2'] == 2 and 
                      digit_count['3'] == 3)
    return "Yes" if conditions_met else "No"

# Read input
N = input().strip()

# Check conditions and print the result
print(check_conditions(N))
```
````

### Extracted final code

````python
from collections import Counter

def check_conditions(N):
    digit_count = Counter(str(N))
    conditions_met = (digit_count['1'] == 1 and 
                      digit_count['2'] == 2 and 
                      digit_count['3'] == 3)
    return "Yes" if conditions_met else "No"

# Read input
N = input().strip()

# Check conditions and print the result
print(check_conditions(N))

````

### Test result

````json
null
````
