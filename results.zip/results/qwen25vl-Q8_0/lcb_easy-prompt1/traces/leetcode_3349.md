# leetcode_3349 — PASS (2/3 attempts passed)

````json
{
  "id": "leetcode_3349",
  "title": "maximum-length-substring-with-two-occurrences",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "leetcode",
  "difficulty": "easy",
  "contest_date": "2024-03-23",
  "format": "functional",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 2
}
````

## User prompt

````text
### Question:
Given a string s, return the maximum length of a substring such that it contains at most two occurrences of each character.
 
Example 1:

Input: s = "bcbbbcba"
Output: 4
Explanation:
The following substring has a length of 4 and contains at most two occurrences of each character: "bcbbbcba".
Example 2:

Input: s = "aaaa"
Output: 2
Explanation:
The following substring has a length of 2 and contains at most two occurrences of each character: "aaaa".
 
Constraints:

2 <= s.length <= 100
s consists only of lowercase English letters.

### Format: You will use the following starter code to write the solution to the problem and enclose your code within delimiters.
```python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        
```

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 27,
  "finish_reason": "stop",
  "prompt_tokens": 320,
  "completion_tokens": 233,
  "gen_seconds": 5.26,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we can use a sliding window approach to track the characters and their counts within the window. We'll expand the window as long as we have at most two occurrences of each character. Once the window exceeds the limit, we'll move the left pointer to shrink the window and adjust the counts until we meet the condition again.

```python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        n = len(s)
        left = 0
        right = 0
        max_length = 0
        char_count = {}

        while right < n:
            char = s[right]
            if char in char_count:
                char_count[char] += 1
            else:
                char_count[char] = 1

            while len(char_count) > 2:
                char = s[left]
                char_count[char] -= 1
                if char_count[char] == 0:
                    del char_count[char]
                left += 1

            max_length = max(max_length, right - left + 1)
            right += 1

        return max_length
```
````

### Extracted final code

````python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        n = len(s)
        left = 0
        right = 0
        max_length = 0
        char_count = {}

        while right < n:
            char = s[right]
            if char in char_count:
                char_count[char] += 1
            else:
                char_count[char] = 1

            while len(char_count) > 2:
                char = s[left]
                char_count[char] -= 1
                if char_count[char] == 0:
                    del char_count[char]
                left += 1

            max_length = max(max_length, right - left + 1)
            right += 1

        return max_length

````

### Test result

````json
{
  "test_index": 0,
  "input": "\"bcbbbcba\"",
  "expected": "4",
  "got": "7",
  "error": null
}
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 27,
  "num_tests": 27,
  "finish_reason": "stop",
  "prompt_tokens": 320,
  "completion_tokens": 307,
  "gen_seconds": 6.82,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Reasoning:

To solve this problem, we can use a sliding window approach to find the longest substring with at most two occurrences of each character. Here's the plan:

1. Use a dictionary to keep track of the count of each character in the current window.
2. Use two pointers to represent the current window's start and end.
3. Expand the window by moving the end pointer to the right, adding characters to the count dictionary.
4. If any character count exceeds two, move the start pointer to the right, reducing the count of characters that exceed the limit.
5. Update the maximum length of the valid substring as we go.

This approach ensures that we efficiently find the longest valid substring in linear time.

```python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        char_count = {}
        start = 0
        max_length = 0
        
        for end in range(len(s)):
            char = s[end]
            if char in char_count:
                char_count[char] += 1
            else:
                char_count[char] = 1
            
            while any(count > 2 for count in char_count.values()):
                char_to_remove = s[start]
                char_count[char_to_remove] -= 1
                if char_count[char_to_remove] == 0:
                    del char_count[char_to_remove]
                start += 1
            
            max_length = max(max_length, end - start + 1)
        
        return max_length
```
````

### Extracted final code

````python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        char_count = {}
        start = 0
        max_length = 0
        
        for end in range(len(s)):
            char = s[end]
            if char in char_count:
                char_count[char] += 1
            else:
                char_count[char] = 1
            
            while any(count > 2 for count in char_count.values()):
                char_to_remove = s[start]
                char_count[char_to_remove] -= 1
                if char_count[char_to_remove] == 0:
                    del char_count[char_to_remove]
                start += 1
            
            max_length = max(max_length, end - start + 1)
        
        return max_length

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 27,
  "num_tests": 27,
  "finish_reason": "stop",
  "prompt_tokens": 320,
  "completion_tokens": 216,
  "gen_seconds": 4.83,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we can use a sliding window approach to keep track of the characters and their counts within the current window. We expand the window by moving the right pointer and shrink it by moving the left pointer when a character count exceeds two. We maintain the maximum length of the window where this condition is satisfied.

Let's implement this approach:

```python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        char_count = {}
        left = 0
        max_length = 0
        
        for right in range(len(s)):
            char = s[right]
            if char in char_count:
                char_count[char] += 1
            else:
                char_count[char] = 1
            
            while char_count[char] > 2:
                char_count[s[left]] -= 1
                if char_count[s[left]] == 0:
                    del char_count[s[left]]
                left += 1
            
            max_length = max(max_length, right - left + 1)
        
        return max_length
```
````

### Extracted final code

````python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        char_count = {}
        left = 0
        max_length = 0
        
        for right in range(len(s)):
            char = s[right]
            if char in char_count:
                char_count[char] += 1
            else:
                char_count[char] = 1
            
            while char_count[char] > 2:
                char_count[s[left]] -= 1
                if char_count[s[left]] == 0:
                    del char_count[s[left]]
                left += 1
            
            max_length = max(max_length, right - left + 1)
        
        return max_length

````

### Test result

````json
null
````
