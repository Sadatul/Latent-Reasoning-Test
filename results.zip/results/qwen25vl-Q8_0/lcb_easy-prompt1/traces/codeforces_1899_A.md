# codeforces_1899_A — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "codeforces_1899_A",
  "title": "A. Game with Integers",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "codeforces",
  "difficulty": "easy",
  "contest_date": "2023-10-17",
  "format": "stdin",
  "prompt_style": 1,
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
Vanya and Vova are playing a game. Players are given an integer $n$. On their turn, the player can add $1$ to the current integer or subtract $1$. The players take turns; Vanya starts. If after Vanya's move the integer is divisible by $3$, then he wins. If $10$ moves have passed and Vanya has not won, then Vova wins.

Write a program that, based on the integer $n$, determines who will win if both players play optimally.

Input

The first line contains the integer $t$ ($1 \leq t \leq 100$) — the number of test cases.

The single line of each test case contains the integer $n$ ($1 \leq n \leq 1000$).

Output

For each test case, print "First" without quotes if Vanya wins, and "Second" without quotes if Vova wins.Sample Input 1:
6

1

3

5

100

999

1000



Sample Output 1:

First
Second
First
First
Second
First


### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 415,
  "completion_tokens": 242,
  "gen_seconds": 5.43,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine the winner based on the initial integer \( n \). The key observation is that if \( n \) is divisible by 3, Vanya wins immediately on his first move. If \( n \) is not divisible by 3, Vova will always win if both players play optimally because after each move, the value of \( n \) changes by 1, and after 10 moves, \( n \) will be changed by 10, which is divisible by 3, ensuring Vova's win.

Here’s the plan:
1. Check if \( n \) is divisible by 3.
2. If yes, Vanya wins.
3. If no, Vova wins after 10 moves.

```python
# Read the number of test cases
t = int(input())

for _ in range(t):
    # Read the integer n
    n = int(input())
    
    # Check if n is divisible by 3
    if n % 3 == 0:
        print("First")  # Vanya wins
    else:
        print("Second")  # Vova wins
```
````

### Extracted final code

````python
# Read the number of test cases
t = int(input())

for _ in range(t):
    # Read the integer n
    n = int(input())
    
    # Check if n is divisible by 3
    if n % 3 == 0:
        print("First")  # Vanya wins
    else:
        print("Second")  # Vova wins

````

### Test result

````json
{
  "test_index": 0,
  "input": "6\n1\n3\n5\n100\n999\n1000\n",
  "expected": "First\nSecond\nFirst\nFirst\nSecond\nFirst\n",
  "got": "Second\nFirst\nSecond\nSecond\nFirst\nSecond\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 415,
  "completion_tokens": 277,
  "gen_seconds": 6.12,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
The game involves adding or subtracting 1 from an integer `n` on each turn. Vanya wins if, after his move, the number is divisible by 3. Vova wins if 10 moves have passed without Vanya winning. To solve this, we need to determine if it's possible for Vanya to force a win given the initial number `n`.

- If `n % 3 == 0`, Vanya can win on his first move if he subtracts 1.
- If `n % 3 == 1`, Vanya can win on his second move if he adds 1.
- If `n % 3 == 2`, Vanya can win on his second move if he subtracts 1.

Given that the maximum number of moves (10) is more than enough to ensure Vanya can make a move and win, the outcome depends on the initial condition of `n % 3`.

### Complete Solution
```python
# Read the number of test cases
t = int(input())

# Process each test case
for _ in range(t):
    n = int(input())
    if n % 3 == 0 or n % 3 == 1 or n % 3 == 2:
        print("First")
    else:
        print("Second")
```
````

### Extracted final code

````python
# Read the number of test cases
t = int(input())

# Process each test case
for _ in range(t):
    n = int(input())
    if n % 3 == 0 or n % 3 == 1 or n % 3 == 2:
        print("First")
    else:
        print("Second")

````

### Test result

````json
{
  "test_index": 0,
  "input": "6\n1\n3\n5\n100\n999\n1000\n",
  "expected": "First\nSecond\nFirst\nFirst\nSecond\nFirst\n",
  "got": "First\nFirst\nFirst\nFirst\nFirst\nFirst\n",
  "error": null
}
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 415,
  "completion_tokens": 369,
  "gen_seconds": 8.12,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves determining the winner of a game based on the initial integer \( n \). The winning condition for Vanya is that the integer becomes divisible by 3 after his move. The game ends after 10 moves if Vanya has not won yet. To solve this, we need to simulate the moves for both players and track the state of the integer.

### Key Observations:
1. Vanya wins if he can make the integer divisible by 3 on his turn.
2. If the integer is already divisible by 3, Vanya loses immediately.
3. If the integer is not divisible by 3, Vova can force Vanya to a losing position if he plays optimally.
4. If 10 moves are passed and Vanya has not won, Vova wins.

### Approach:
- Start with the integer \( n \).
- Simulate Vanya's move by adding or subtracting 1.
- Check if the new integer is divisible by 3 after Vanya's move.
- If Vanya wins, return "First".
- If 10 moves have passed without Vanya winning, return "Second".

Let's implement the code to solve this:

```python
def determine_winner(n):
    moves = 0
    while moves < 10:
        if n % 3 == 0:
            return "Second"
        n = (n + 1) % 1000  # Vanya can add 1 or subtract 1, take the result modulo 1000 to handle large numbers
        moves += 1
    return "Second"

t = int(input())
for _ in range(t):
    n = int(input())
    print("First" if n % 3 == 0 else determine_winner(n))
```
````

### Extracted final code

````python
def determine_winner(n):
    moves = 0
    while moves < 10:
        if n % 3 == 0:
            return "Second"
        n = (n + 1) % 1000  # Vanya can add 1 or subtract 1, take the result modulo 1000 to handle large numbers
        moves += 1
    return "Second"

t = int(input())
for _ in range(t):
    n = int(input())
    print("First" if n % 3 == 0 else determine_winner(n))

````

### Test result

````json
{
  "test_index": 0,
  "input": "6\n1\n3\n5\n100\n999\n1000\n",
  "expected": "First\nSecond\nFirst\nFirst\nSecond\nFirst\n",
  "got": "Second\nFirst\nSecond\nSecond\nFirst\nSecond\n",
  "error": null
}
````
