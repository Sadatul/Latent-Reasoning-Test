# leetcode_3372 — PASS (1/3 attempts passed)

````json
{
  "id": "leetcode_3372",
  "title": "longest-strictly-increasing-or-strictly-decreasing-subarray",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "leetcode",
  "difficulty": "easy",
  "contest_date": "2024-04-06",
  "format": "functional",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
You are given an array of integers nums. Return the length of the longest subarray of nums which is either strictly increasing or strictly decreasing.
 
Example 1:

Input: nums = [1,4,3,3,2]
Output: 2
Explanation:
The strictly increasing subarrays of nums are [1], [2], [3], [3], [4], and [1,4].
The strictly decreasing subarrays of nums are [1], [2], [3], [3], [4], [3,2], and [4,3].
Hence, we return 2.

Example 2:

Input: nums = [3,3,3,3]
Output: 1
Explanation:
The strictly increasing subarrays of nums are [3], [3], [3], and [3].
The strictly decreasing subarrays of nums are [3], [3], [3], and [3].
Hence, we return 1.

Example 3:

Input: nums = [3,2,1]
Output: 3
Explanation:
The strictly increasing subarrays of nums are [3], [2], and [1].
The strictly decreasing subarrays of nums are [3], [2], [1], [3,2], [2,1], and [3,2,1].
Hence, we return 3.

 
Constraints:

1 <= nums.length <= 50
1 <= nums[i] <= 50

### Format: You will use the following starter code to write the solution to the problem and enclose your code within delimiters.
```python
class Solution:
    def longestMonotonicSubarray(self, nums: List[int]) -> int:
        
```

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 2,
  "num_tests": 28,
  "finish_reason": "stop",
  "prompt_tokens": 497,
  "completion_tokens": 345,
  "gen_seconds": 7.7,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to find the longest subarray that is either strictly increasing or strictly decreasing. We can achieve this by iterating through the array and keeping track of the current increasing/decreasing sequence length. Whenever we encounter a number that breaks the sequence (either increasing becomes decreasing or vice versa), we update our maximum length. We then restart the sequence with the new number.

Here's the detailed explanation and the corresponding code:

1. Initialize a variable `max_length` to keep track of the maximum length of the subarray found so far.
2. Initialize a variable `current_length` to keep track of the current length of the increasing/decreasing sequence.
3. Iterate through the array, starting from the second element.
4. For each element, check if it continues the current sequence (either increasing or decreasing). If it does, increment `current_length`.
5. If it breaks the current sequence (i.e., the sequence changes from increasing to decreasing or vice versa), update `max_length` with the maximum of `max_length` and `current_length`.
6. Reset `current_length` to 1 for the new sequence.
7. After the loop, return `max_length`.

Let's implement this logic in the code:

```python
class Solution:
    def longestMonotonicSubarray(self, nums: List[int]) -> int:
        max_length = 1
        current_length = 1
        for i in range(1, len(nums)):
            if nums[i] > nums[i-1]:
                current_length += 1
            else:
                current_length = 1
            max_length = max(max_length, current_length)
        return max_length
```
````

### Extracted final code

````python
class Solution:
    def longestMonotonicSubarray(self, nums: List[int]) -> int:
        max_length = 1
        current_length = 1
        for i in range(1, len(nums)):
            if nums[i] > nums[i-1]:
                current_length += 1
            else:
                current_length = 1
            max_length = max(max_length, current_length)
        return max_length

````

### Test result

````json
{
  "test_index": 2,
  "input": "[3, 2, 1]",
  "expected": "3",
  "got": "1",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 28,
  "finish_reason": "stop",
  "prompt_tokens": 497,
  "completion_tokens": 195,
  "gen_seconds": 4.32,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To solve this problem, we need to find the longest subarray that is either strictly increasing or strictly decreasing. We can achieve this by iterating through the array and keeping track of the current length of the increasing and decreasing subarrays. Whenever we encounter a number that disrupts the increasing or decreasing sequence, we update the global maximum length of such a subarray.

### Complete Solution Code:
```python
class Solution:
    def longestMonotonicSubarray(self, nums: List[int]) -> int:
        max_length = 1
        current_length = 1
        
        for i in range(1, len(nums)):
            if nums[i] > nums[i-1]:
                current_length += 1
            elif nums[i] < nums[i-1]:
                current_length += 1
            else:
                current_length = 1
            
            max_length = max(max_length, current_length)
        
        return max_length
```
````

### Extracted final code

````python
class Solution:
    def longestMonotonicSubarray(self, nums: List[int]) -> int:
        max_length = 1
        current_length = 1
        
        for i in range(1, len(nums)):
            if nums[i] > nums[i-1]:
                current_length += 1
            elif nums[i] < nums[i-1]:
                current_length += 1
            else:
                current_length = 1
            
            max_length = max(max_length, current_length)
        
        return max_length

````

### Test result

````json
{
  "test_index": 0,
  "input": "[1, 4, 3, 3, 2]",
  "expected": "2",
  "got": "3",
  "error": null
}
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 28,
  "num_tests": 28,
  "finish_reason": "stop",
  "prompt_tokens": 497,
  "completion_tokens": 250,
  "gen_seconds": 5.51,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem requires finding the length of the longest subarray that is either strictly increasing or strictly decreasing in the given array. We can achieve this by iterating through the array and tracking the lengths of the increasing and decreasing sequences. We update the maximum length whenever we encounter a point where the sequence breaks.

Here's the plan:
1. Initialize variables to keep track of the current increasing, decreasing, and maximum lengths.
2. Iterate through the array, tracking if the sequence is increasing or decreasing.
3. Update the maximum length when the sequence breaks.
4. Return the maximum length found.

```python
class Solution:
    def longestMonotonicSubarray(self, nums: List[int]) -> int:
        increasing = 1
        decreasing = 1
        max_length = 1

        for i in range(1, len(nums)):
            if nums[i] > nums[i-1]:
                increasing += 1
                decreasing = 1
            elif nums[i] < nums[i-1]:
                decreasing += 1
                increasing = 1
            else:
                increasing = 1
                decreasing = 1
            max_length = max(max_length, increasing, decreasing)

        return max_length
```
````

### Extracted final code

````python
class Solution:
    def longestMonotonicSubarray(self, nums: List[int]) -> int:
        increasing = 1
        decreasing = 1
        max_length = 1

        for i in range(1, len(nums)):
            if nums[i] > nums[i-1]:
                increasing += 1
                decreasing = 1
            elif nums[i] < nums[i-1]:
                decreasing += 1
                increasing = 1
            else:
                increasing = 1
                decreasing = 1
            max_length = max(max_length, increasing, decreasing)

        return max_length

````

### Test result

````json
null
````
