# atcoder_abc303_a — PASS (1/3 attempts passed)

````json
{
  "id": "atcoder_abc303_a",
  "title": "Similar String",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2023-05-27",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
Two characters x and y are called similar characters if and only if one of the following conditions is satisfied:

- x and y are the same character.
- One of x and y is 1 and the other is l.
- One of x and y is 0 and the other is o.

Two strings S and T, each of length N, are called similar strings if and only if:

- for all i\ (1\leq i\leq N), the i-th character of S and the i-th character of T are similar characters.

Given two length-N strings S and T consisting of lowercase English letters and digits, determine if S and T are similar strings.

Input

The input is given from Standard Input in the following format:
N
S
T

Output

Print Yes if S and T are similar strings, and No otherwise.

Constraints


- N is an integer between 1 and 100.
- Each of S and T is a string of length N consisting of lowercase English letters and digits.

Sample Input 1

3
l0w
1ow

Sample Output 1

Yes

The 1-st character of S is l, and the 1-st character of T is 1.  These are similar characters.
The 2-nd character of S is 0, and the 2-nd character of T is o.  These are similar characters.
The 3-rd character of S is w, and the 3-rd character of T is w.  These are similar characters.
Thus, S and T are similar strings.

Sample Input 2

3
abc
arc

Sample Output 2

No

The 2-nd character of S is b, and the 2-nd character of T is r.  These are not similar characters.
Thus, S and T are not similar strings.

Sample Input 3

4
nok0
n0ko

Sample Output 3

Yes

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 580,
  "completion_tokens": 248,
  "gen_seconds": 5.62,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if each character in string `S` can be mapped to a similar character in string `T` based on the given conditions. The conditions are:

1. Characters are the same.
2. One character is 'l' and the other is '1'.
3. One character is 'o' and the other is '0'.

Let's implement this logic step by step:

1. Iterate through each character of `S` and `T`.
2. Check if the characters are similar according to the given rules.
3. If all characters match the similarity conditions, return "Yes".
4. If any pair of characters do not match the conditions, return "No".

Here's the complete solution:

```python
N = int(input())
S = input()
T = input()

similar_conditions = {'l': '1', 'o': '0'}

def is_similar(x, y):
    if x == y:
        return True
    return x in similar_conditions and y == similar_conditions[x]

for i in range(N):
    if is_similar(S[i], T[i]) == False:
        print("No")
        break
else:
    print("Yes")
```
````

### Extracted final code

````python
N = int(input())
S = input()
T = input()

similar_conditions = {'l': '1', 'o': '0'}

def is_similar(x, y):
    if x == y:
        return True
    return x in similar_conditions and y == similar_conditions[x]

for i in range(N):
    if is_similar(S[i], T[i]) == False:
        print("No")
        break
else:
    print("Yes")

````

### Test result

````json
{
  "test_index": 0,
  "input": "3\nl0w\n1ow\n",
  "expected": "Yes\n",
  "got": "No\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 12,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 580,
  "completion_tokens": 319,
  "gen_seconds": 7.02,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To determine if two strings `S` and `T` are similar, we need to check each corresponding pair of characters. Two characters are similar if they are the same, or if one is '1' and the other is 'l', or if one is '0' and the other is 'o'. This can be checked using a simple comparison.

### Complete Solution Code:
```python
n = int(input())
s = input()
t = input()

similar = {'0': 'o', '1': 'l', 'l': '1', 'o': '0', 'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e', 'f': 'f', 'g': 'g', 'h': 'h', 'i': 'i', 'j': 'j', 'k': 'k', 'l': '1', 'm': 'm', 'n': 'n', 'o': '0', 'p': 'p', 'q': 'q', 'r': 'r', 's': 's', 't': 't', 'u': 'u', 'v': 'v', 'w': 'w', 'x': 'x', 'y': 'y', 'z': 'z'}

for i in range(n):
    if s[i] not in similar or similar[s[i]] != t[i]:
        print('No')
        break
else:
    print('Yes')
```
````

### Extracted final code

````python
n = int(input())
s = input()
t = input()

similar = {'0': 'o', '1': 'l', 'l': '1', 'o': '0', 'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e', 'f': 'f', 'g': 'g', 'h': 'h', 'i': 'i', 'j': 'j', 'k': 'k', 'l': '1', 'm': 'm', 'n': 'n', 'o': '0', 'p': 'p', 'q': 'q', 'r': 'r', 's': 's', 't': 't', 'u': 'u', 'v': 'v', 'w': 'w', 'x': 'x', 'y': 'y', 'z': 'z'}

for i in range(n):
    if s[i] not in similar or similar[s[i]] != t[i]:
        print('No')
        break
else:
    print('Yes')

````

### Test result

````json
{
  "test_index": 12,
  "input": "100\nloo0jl1la3llo010molkplool60xnf113100l11tkln110goll0z11o004ulow0mz0looolunooob31l0l060n1ol1g00y510g1j\n100oj1l1a3110olom01kp1o016oxnfll3loo1lltk1nllog011ozll0oo4u10womzo100o1un000b3l1o1o6onl01lgooy5loglj\n",
  "expected": "Yes\n",
  "got": "No\n",
  "error": null
}
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 15,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 580,
  "completion_tokens": 256,
  "gen_seconds": 5.58,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves checking if two strings S and T are similar based on the given conditions. We need to compare each character of S and T and check if they are similar according to the provided rules.

Here's how we can approach the solution:
1. Iterate through each character of the strings.
2. Check if each pair of characters satisfies the similarity conditions.
3. Print "Yes" if all pairs are similar, otherwise print "No".

Let's implement this logic in Python.
```python
def are_similar(s, t):
    for char_s, char_t in zip(s, t):
        if char_s == '1' and char_t == 'l':
            continue
        if char_s == '0' and char_t == 'o':
            continue
        if char_s == 'l' and char_t == '1':
            continue
        if char_s == 'o' and char_t == '0':
            continue
        if char_s != char_t:
            return False
    return True

if __name__ == "__main__":
    n = int(input())
    s = input()
    t = input()
    if are_similar(s, t):
        print("Yes")
    else:
        print("No")
```
````

### Extracted final code

````python
def are_similar(s, t):
    for char_s, char_t in zip(s, t):
        if char_s == '1' and char_t == 'l':
            continue
        if char_s == '0' and char_t == 'o':
            continue
        if char_s == 'l' and char_t == '1':
            continue
        if char_s == 'o' and char_t == '0':
            continue
        if char_s != char_t:
            return False
    return True

if __name__ == "__main__":
    n = int(input())
    s = input()
    t = input()
    if are_similar(s, t):
        print("Yes")
    else:
        print("No")

````

### Test result

````json
null
````
