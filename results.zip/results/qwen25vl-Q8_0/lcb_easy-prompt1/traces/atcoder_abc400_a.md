# atcoder_abc400_a — PASS (1/3 attempts passed)

````json
{
  "id": "atcoder_abc400_a",
  "title": "ABC400 Party",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2025-04-05",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
In the ceremony commemorating ABC400, we want to arrange 400 people in a rectangular formation of A rows and B columns without any gaps.
You are given a positive integer A. Print the value of a positive integer B for which such an arrangement is possible. If there is no such positive integer B, print -1.

Input

The input is given from Standard Input in the following format:
A

Output

Print the value of B or -1 as specified by the problem statement.

Constraints


- A is an integer between 1 and 400, inclusive.

Sample Input 1

10

Sample Output 1

40

We can arrange 400 people in 10 rows and 40 columns.

Sample Input 2

11

Sample Output 2

-1

Sample Input 3

400

Sample Output 3

1

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 1,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 361,
  "completion_tokens": 166,
  "gen_seconds": 3.7,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to find a positive integer \( B \) such that the total number of people (400) can be arranged in a rectangular formation of \( A \) rows and \( B \) columns. This means that \( A \times B = 400 \). If \( A \) is given and \( 400 \) is divisible by \( A \), then \( B = \frac{400}{A} \) will be a positive integer. Otherwise, \( B \) will not be a positive integer and we should print -1.

Let's implement this logic:
```python
A = int(input())
B = 400 // A
if B > 0:
    print(B)
else:
    print(-1)
```
````

### Extracted final code

````python
A = int(input())
B = 400 // A
if B > 0:
    print(B)
else:
    print(-1)

````

### Test result

````json
{
  "test_index": 1,
  "input": "11",
  "expected": "-1",
  "got": "36\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 361,
  "completion_tokens": 191,
  "gen_seconds": 4.19,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To solve this problem, we need to find a positive integer \( B \) such that \( A \times B = 400 \). This means \( B \) should be a divisor of 400. If \( A \) is given, we can compute \( B \) as \( 400 / A \). If \( B \) is an integer, then \( A \) can be arranged into a rectangular formation of \( A \) rows and \( B \) columns. If \( B \) is not an integer, then it is not possible to arrange 400 people in such a formation, and we should print -1.

### Complete Solution:
```python
A = int(input())
if A == 1 or A == 400:
    B = 400 // A
    print(B)
else:
    print(-1)
```
````

### Extracted final code

````python
A = int(input())
if A == 1 or A == 400:
    B = 400 // A
    print(B)
else:
    print(-1)

````

### Test result

````json
{
  "test_index": 0,
  "input": "10",
  "expected": "40",
  "got": "-1\n",
  "error": null
}
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 43,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 361,
  "completion_tokens": 177,
  "gen_seconds": 3.89,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem requires us to find the number of columns \( B \) for which 400 people can be arranged in a rectangular formation of \( A \) rows and \( B \) columns. We need to check if \( B \) is an integer such that \( A \times B = 400 \). If no such \( B \) exists, we print -1.

Given that \( A \) is between 1 and 400, we can calculate \( B \) as \( \frac{400}{A} \) and check if \( B \) is an integer.
```python
A = int(input())
B = 400 // A
if 400 % A == 0 and B > 0:
    print(B)
else:
    print(-1)
```
````

### Extracted final code

````python
A = int(input())
B = 400 // A
if 400 % A == 0 and B > 0:
    print(B)
else:
    print(-1)

````

### Test result

````json
null
````
