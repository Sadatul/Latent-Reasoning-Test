# atcoder_abc392_a — PASS (3/3 attempts passed)

````json
{
  "id": "atcoder_abc392_a",
  "title": "Shuffled Equation",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2025-02-08",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 3
}
````

## User prompt

````text
### Question:
You are given a sequence of integers A = (A_1, A_2, A_3).
Let B = (B_1, B_2, B_3) be any permutation of A.
Determine whether it is possible that B_1 \times B_2 = B_3.

Input

The input is given from Standard Input in the following format:
A_1 A_2 A_3

Output

If it is possible that B_1 \times B_2 = B_3, print Yes; otherwise, print No.

Constraints


- All input values are integers.
- 1 \le A_1, A_2, A_3 \le 100

Sample Input 1

3 15 5

Sample Output 1

Yes

Here, A=(3,15,5).
By rearranging it as B=(3,5,15), we can satisfy B_1 \times B_2 = B_3.

Sample Input 2

5 3 2

Sample Output 2

No

No permutation of B satisfies B_1 \times B_2 = B_3.

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 42,
  "num_tests": 42,
  "finish_reason": "stop",
  "prompt_tokens": 417,
  "completion_tokens": 273,
  "gen_seconds": 6.08,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if there exists a permutation of the given integers such that the product of the first two integers equals the third integer. We can achieve this by iterating through all permutations of the integers and checking the condition.

Here is the algorithm:
1. Import the `itertools` module to generate permutations of the given integers.
2. Iterate over all permutations of the integers.
3. For each permutation, check if the first two integers multiplied together equal the third integer.
4. If such a permutation is found, print "Yes" and exit.
5. If no such permutation is found after checking all permutations, print "No".

Let's implement this logic in the code.

```python
import itertools

def check_permutation(A):
    # Generate all permutations of the input list
    for perm in itertools.permutations(A):
        # Check if the product of the first two integers equals the third integer
        if perm[0] * perm[1] == perm[2]:
            return True
    return False

# Read input from stdin
A1, A2, A3 = map(int, input().split())
A = [A1, A2, A3]

# Check and print the result
if check_permutation(A):
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
import itertools

def check_permutation(A):
    # Generate all permutations of the input list
    for perm in itertools.permutations(A):
        # Check if the product of the first two integers equals the third integer
        if perm[0] * perm[1] == perm[2]:
            return True
    return False

# Read input from stdin
A1, A2, A3 = map(int, input().split())
A = [A1, A2, A3]

# Check and print the result
if check_permutation(A):
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 42,
  "num_tests": 42,
  "finish_reason": "stop",
  "prompt_tokens": 417,
  "completion_tokens": 215,
  "gen_seconds": 4.73,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To solve this problem, we need to check if there exists a permutation of the sequence \((A_1, A_2, A_3)\) such that \(B_1 \times B_2 = B_3\). Here's the algorithm:

1. Iterate through all permutations of the sequence.
2. For each permutation, check if the product of the first two elements equals the third element.
3. If such a permutation is found, print "Yes" and exit.
4. If no such permutation is found after checking all possibilities, print "No".

### Complete Solution:
```python
import itertools

def check_permutation(A):
    for perm in itertools.permutations(A):
        if perm[0] * perm[1] == perm[2]:
            return True
    return False

# Read input
A = list(map(int, input().split()))

# Check if there exists a permutation satisfying the condition
if check_permutation(A):
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
import itertools

def check_permutation(A):
    for perm in itertools.permutations(A):
        if perm[0] * perm[1] == perm[2]:
            return True
    return False

# Read input
A = list(map(int, input().split()))

# Check if there exists a permutation satisfying the condition
if check_permutation(A):
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 42,
  "num_tests": 42,
  "finish_reason": "stop",
  "prompt_tokens": 417,
  "completion_tokens": 234,
  "gen_seconds": 5.14,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem requires us to determine if there exists a permutation of the given sequence \(A = (A_1, A_2, A_3)\) such that the product of the first two elements equals the third element. We need to check if there is any permutation \((B_1, B_2, B_3)\) where \(B_1 \times B_2 = B_3\).

Given the constraint \(1 \le A_1, A_2, A_3 \le 100\), we can iterate through all possible permutations of \(A\). If we find such a permutation, we return "Yes". If no permutation satisfies the condition, we return "No".
```python
# Read the input
A1, A2, A3 = map(int, input().split())

# Check all permutations
for perm in permutations([A1, A2, A3]):
    B1, B2, B3 = perm
    if B1 * B2 == B3:
        print("Yes")
        break
else:
    print("No")
```
````

### Extracted final code

````python
# Read the input
A1, A2, A3 = map(int, input().split())

# Check all permutations
for perm in permutations([A1, A2, A3]):
    B1, B2, B3 = perm
    if B1 * B2 == B3:
        print("Yes")
        break
else:
    print("No")

````

### Test result

````json
null
````
