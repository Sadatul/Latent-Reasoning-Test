# atcoder_abc386_a — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "atcoder_abc386_a",
  "title": "Full House 2",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-12-28",
  "format": "stdin",
  "prompt_style": 1,
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
There are four cards with integers A,B,C,D written on them.
Determine whether a Full House can be formed by adding one card.
A set of five cards is called a Full House if and only if the following condition is satisfied:

- For two distinct integers x and y, there are three cards with x written on them and two cards with y written on them.

Input

The input is given from Standard Input in the following format:
A B C D

Output

If adding one card can form a Full House, print Yes; otherwise, print No.

Constraints


- All input values are integers.
- 1 \le A,B,C,D \le 13

Sample Input 1

7 7 7 1

Sample Output 1

Yes

Adding 1 to 7,7,7,1 forms a Full House.

Sample Input 2

13 12 11 10

Sample Output 2

No

Adding anything to 13,12,11,10 does not form a Full House.

Sample Input 3

3 3 5 5

Sample Output 3

Yes

Adding 3,3,5,5 to 3 forms a Full House.
Also, adding 5 forms a Full House.

Sample Input 4

8 8 8 8

Sample Output 4

No

Adding anything to 8,8,8,8 does not form a Full House.
Note that five identical cards do not form a Full House.

Sample Input 5

1 3 4 1

Sample Output 5

No

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 45,
  "finish_reason": "stop",
  "prompt_tokens": 511,
  "completion_tokens": 498,
  "gen_seconds": 10.98,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if adding one card can form a Full House. A Full House requires having three cards of one value and two cards of another value. We can iterate through the possible values from 1 to 13 to see if we can achieve this condition.

Here's the step-by-step algorithm:
1. Iterate through each of the values A, B, C, D.
2. For each value, count the occurrences of that value in the set {A, B, C, D}.
3. Check if there is a value that has exactly three occurrences and another value that has exactly two occurrences.
4. If such a pair is found, print "Yes". Otherwise, print "No".

Let's implement this logic in Python:

```python
from collections import Counter

# Read input
input_str = input()
A, B, C, D = map(int, input_str.split())

# Count occurrences of each number
counts = Counter([A, B, C, D])

# Check if a Full House can be formed by adding one card
for value in range(1, 14):
    if value in counts:
        count_value = counts[value]
        if count_value == 2:
            for other_value in range(1, 14):
                if other_value != value and other_value in counts:
                    other_count = counts[other_value]
                    if other_count == 3:
                        print("Yes")
                        break
            else:
                continue
        elif count_value == 3:
            for other_value in range(1, 14):
                if other_value != value and other_value in counts:
                    other_count = counts[other_value]
                    if other_count == 2:
                        print("Yes")
                        break
            else:
                continue
    else:
        for other_value in range(1, 14):
            if other_value != value and other_value in counts:
                other_count = counts[other_value]
                if other_count == 3:
                    print("Yes")
                    break
        else:
            continue
else:
    print("No")
```

This code checks all possible values and counts their occurrences. It then verifies if the conditions for a Full House are met by checking for three one value and two another value, and vice versa. If such a configuration is found, it prints "Yes"; otherwise, it prints "No".
````

### Extracted final code

````python
from collections import Counter

# Read input
input_str = input()
A, B, C, D = map(int, input_str.split())

# Count occurrences of each number
counts = Counter([A, B, C, D])

# Check if a Full House can be formed by adding one card
for value in range(1, 14):
    if value in counts:
        count_value = counts[value]
        if count_value == 2:
            for other_value in range(1, 14):
                if other_value != value and other_value in counts:
                    other_count = counts[other_value]
                    if other_count == 3:
                        print("Yes")
                        break
            else:
                continue
        elif count_value == 3:
            for other_value in range(1, 14):
                if other_value != value and other_value in counts:
                    other_count = counts[other_value]
                    if other_count == 2:
                        print("Yes")
                        break
            else:
                continue
    else:
        for other_value in range(1, 14):
            if other_value != value and other_value in counts:
                other_count = counts[other_value]
                if other_count == 3:
                    print("Yes")
                    break
        else:
            continue
else:
    print("No")

````

### Test result

````json
{
  "test_index": 0,
  "input": "7 7 7 1",
  "expected": "Yes",
  "got": "Yes\nYes\nYes\nYes\nYes\nYes\nYes\nYes\nYes\nYes\nYes\nNo\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 45,
  "finish_reason": "stop",
  "prompt_tokens": 511,
  "completion_tokens": 348,
  "gen_seconds": 7.61,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To determine if adding one card can form a Full House, we need to check if the current combination of cards can be transformed into a set of five cards where there are three cards of one value and two cards of another value. Here’s the approach:

1. **Count the occurrences of each card** (A, B, C, D).
2. **Check the counts**:
   - If there is a value with 3 occurrences and another value with 2 occurrences, then adding one more card of the 2-count value will form a Full House.
   - If there is a value with 2 occurrences and another value with 3 occurrences, then adding one more card of the 3-count value will form a Full House.
   - If any other combination of occurrences does not meet the criteria, it cannot form a Full House.

### Complete Solution:
```python
# Read the input
cards = list(map(int, input().split()))

# Count occurrences of each card
count = [0] * 14
for card in cards:
    count[card] += 1

# Check for Full House formation
full_house = False
for i in range(1, 14):
    if count[i] == 3 and (count[i+1] == 2 or count[i-1] == 2):
        full_house = True
        break
    elif count[i] == 2 and (count[i+1] == 3 or count[i-1] == 3):
        full_house = True
        break

# Output the result
if full_house:
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
# Read the input
cards = list(map(int, input().split()))

# Count occurrences of each card
count = [0] * 14
for card in cards:
    count[card] += 1

# Check for Full House formation
full_house = False
for i in range(1, 14):
    if count[i] == 3 and (count[i+1] == 2 or count[i-1] == 2):
        full_house = True
        break
    elif count[i] == 2 and (count[i+1] == 3 or count[i-1] == 3):
        full_house = True
        break

# Output the result
if full_house:
    print("Yes")
else:
    print("No")

````

### Test result

````json
{
  "test_index": 0,
  "input": "7 7 7 1",
  "expected": "Yes",
  "got": "No\n",
  "error": null
}
````

## Attempt 3 — RUNTIME_ERROR

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "runtime_error",
  "num_passed": 0,
  "num_tests": 45,
  "finish_reason": "stop",
  "prompt_tokens": 511,
  "completion_tokens": 148,
  "gen_seconds": 3.25,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
To determine if a Full House can be formed by adding one card, we need to check the conditions for forming a Full House. A Full House requires having three cards of one number and two cards of another number. We can iterate through each card and count the occurrences of each number. Then, we check if there exists a pair of numbers where one number is repeated three times and another is repeated twice.

Here's the plan:
1. Input four cards.
2. Count the occurrences of each number.
3. Check if there exists a combination where one number appears three times and another appears twice.
4. If found, print "Yes"; otherwise, print "No".

```python
<complete solution code>
```
````

### Extracted final code

````python
<complete solution code>

````

### Test result

````json
{
  "test_index": 0,
  "input": "7 7 7 1",
  "expected": "Yes",
  "got": "",
  "error": "  File \"/tmp/eval_drmgezdj/solution.py\", line 26\n    <complete solution code>\n    ^\nSyntaxError: invalid syntax\n"
}
````
