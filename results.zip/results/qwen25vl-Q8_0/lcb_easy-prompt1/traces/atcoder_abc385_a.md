# atcoder_abc385_a — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "atcoder_abc385_a",
  "title": "Equally",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-12-21",
  "format": "stdin",
  "prompt_style": 1,
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
You are given three integers A,B,C. Determine whether it is possible to divide these three integers into two or more groups so that these groups have equal sums.

Input

The input is given from Standard Input in the following format:
A B C

Output

If it is possible to divide A,B,C into two or more groups with equal sums, print Yes; otherwise, print No.

Constraints


- 1 \leq A,B,C \leq 1000
- All input values are integers.

Sample Input 1

3 8 5

Sample Output 1

Yes

For example, by dividing into two groups (3,5) and (8), each group can have the sum 8.

Sample Input 2

2 2 2

Sample Output 2

Yes

By dividing into three groups (2),(2),(2), each group can have the sum 2.

Sample Input 3

1 2 4

Sample Output 3

No

No matter how you divide them into two or more groups, it is not possible to make the sums equal.

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 3,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 401,
  "completion_tokens": 473,
  "gen_seconds": 10.31,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if it's possible to divide the three integers into two or more groups such that the sums of the groups are equal. This can be done by calculating the total sum of A, B, and C. If the total sum is divisible by 2 or 3 (indicating it's possible to divide into two or three groups respectively), we can check if such a division is possible by recursively trying to form groups with equal sums.

Here's the step-by-step approach:
1. Calculate the total sum of A, B, and C.
2. Check if the total sum is divisible by 2 or 3.
3. If divisible, check if it's possible to form such groups.
4. If not, print 'No'.

The divisibility check and group formation can be handled using a recursive function to try different combinations.

```python
def is_possible(groups, total_sum, remaining_sum, count):
    if remaining_sum == 0:
        return True
    if count == len(groups):
        return False
    for i in [0, 1]:
        if is_possible(groups, total_sum, remaining_sum - groups[count][i], count + 1):
            return True
    return False

def can_divide(A, B, C):
    total_sum = A + B + C
    if total_sum % 2 == 0:
        for i in range(1, total_sum // 2 + 1):
            groups = [(0, 0), (i, total_sum - i)]
            if is_possible(groups, total_sum, total_sum // 2, 0):
                return True
    elif total_sum % 3 == 0:
        for i in range(1, total_sum // 3 + 1):
            for j in range(1, total_sum // 3 + 1):
                groups = [(0, 0), (i, total_sum - i - j), (j, total_sum - j)]
                if is_possible(groups, total_sum, total_sum // 3, 0):
                    return True
    return False

A, B, C = map(int, input().split())
print("Yes" if can_divide(A, B, C) else "No")
```
````

### Extracted final code

````python
def is_possible(groups, total_sum, remaining_sum, count):
    if remaining_sum == 0:
        return True
    if count == len(groups):
        return False
    for i in [0, 1]:
        if is_possible(groups, total_sum, remaining_sum - groups[count][i], count + 1):
            return True
    return False

def can_divide(A, B, C):
    total_sum = A + B + C
    if total_sum % 2 == 0:
        for i in range(1, total_sum // 2 + 1):
            groups = [(0, 0), (i, total_sum - i)]
            if is_possible(groups, total_sum, total_sum // 2, 0):
                return True
    elif total_sum % 3 == 0:
        for i in range(1, total_sum // 3 + 1):
            for j in range(1, total_sum // 3 + 1):
                groups = [(0, 0), (i, total_sum - i - j), (j, total_sum - j)]
                if is_possible(groups, total_sum, total_sum // 3, 0):
                    return True
    return False

A, B, C = map(int, input().split())
print("Yes" if can_divide(A, B, C) else "No")

````

### Test result

````json
{
  "test_index": 3,
  "input": "3 14 4",
  "expected": "No\n",
  "got": "Yes\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 3,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 401,
  "completion_tokens": 240,
  "gen_seconds": 5.21,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To solve this problem, we need to check if it's possible to divide the integers A, B, and C into two or more groups with equal sums. Here are the steps:
1. Check if the total sum of A, B, and C is divisible by 2 or 3 (this is necessary to divide them into groups with equal sums).
2. If the total sum is divisible by 2, it means the sum can be divided into two equal groups.
3. If the total sum is divisible by 3, it means the sum can be divided into three equal groups.
4. If the sum is neither divisible by 2 nor 3, it's not possible to divide the numbers into groups with equal sums.

### Complete Solution:
```python
# Reading input
A, B, C = map(int, input().split())

# Calculate the total sum
total_sum = A + B + C

# Check if the total sum is divisible by 2 or 3
if total_sum % 2 == 0 or total_sum % 3 == 0:
    print('Yes')
else:
    print('No')
```
````

### Extracted final code

````python
# Reading input
A, B, C = map(int, input().split())

# Calculate the total sum
total_sum = A + B + C

# Check if the total sum is divisible by 2 or 3
if total_sum % 2 == 0 or total_sum % 3 == 0:
    print('Yes')
else:
    print('No')

````

### Test result

````json
{
  "test_index": 3,
  "input": "3 14 4",
  "expected": "No\n",
  "got": "Yes\n",
  "error": null
}
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 401,
  "completion_tokens": 226,
  "gen_seconds": 4.92,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem requires us to determine if we can partition three integers \(A\), \(B\), and \(C\) into two or more groups such that the sums of the groups are equal. This is essentially asking if the total sum \(A + B + C\) can be evenly divided by at least 2 groups (since having just one group means the sum is not divided).

The steps are:
1. Calculate the total sum \(T = A + B + C\).
2. Check if \(T\) is divisible by at least 2 (since having just one group or grouping them into more is not a valid partition).
3. If \(T\) is divisible by 2 or more, it means we can form equal groups.

Let's implement this logic in code:
```python

```python
# Read input
A, B, C = map(int, input().split())

# Calculate the total sum
T = A + B + C

# Check divisibility
if T % 2 == 0:
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python


````

### Test result

````json
{
  "test_index": 0,
  "input": "3 8 5",
  "expected": "Yes",
  "got": "",
  "error": null
}
````
