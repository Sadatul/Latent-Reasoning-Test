# atcoder_abc400_b — PASS (2/3 attempts passed)

````json
{
  "id": "atcoder_abc400_b",
  "title": "Sum of Geometric Series",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2025-04-05",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 2
}
````

## User prompt

````text
### Question:
You are given two positive integers N and M.
Let X = \displaystyle\sum_{i = 0}^{M} N^i. If X \leq 10^9, print the value of X. If X > 10^9, print inf.

Input

The input is given from Standard Input in the following format:
N M

Output

Print the value of X or inf as specified by the problem statement.

Constraints


- 1 \leq N \leq 10^9
- 1 \leq M \leq 100
- All input values are integers.

Sample Input 1

7 3

Sample Output 1

400

X = 1 + 7 + 49 + 343 = 400. Since 400 \leq 10^9, print 400.

Sample Input 2

1000000 2

Sample Output 2

inf

X = 1000001000001 > 10^9, so print inf.

Sample Input 3

999999999 1

Sample Output 3

1000000000

Sample Input 4

998244353 99

Sample Output 4

inf

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 473,
  "completion_tokens": 271,
  "gen_seconds": 6.0,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves calculating the sum of a geometric series \(X = \sum_{i=0}^{M} N^i\). The series is \(1 + N + N^2 + \cdots + N^M\). The sum of such a series can be calculated using the formula \(X = \frac{N^{M+1} - 1}{N - 1}\) if \(N \neq 1\). If \(N = 1\), the sum is \(M + 1\). Given the constraints, we need to compute \(X\) and check if it fits within the limit \(10^9\). If it does, we print \(X\); otherwise, we print "inf".

Let's implement this in Python:
```python
# Read input values
N, M = map(int, input().split())

# Check if N is 1 to directly compute the sum
if N == 1:
    X = M + 1
else:
    # Calculate X using the geometric series sum formula
    X = (N**(M+1) - 1) // (N - 1)

# Check if X is within the limit
if X <= 10**9:
    print(X)
else:
    print("inf")
```
````

### Extracted final code

````python
# Read input values
N, M = map(int, input().split())

# Check if N is 1 to directly compute the sum
if N == 1:
    X = M + 1
else:
    # Calculate X using the geometric series sum formula
    X = (N**(M+1) - 1) // (N - 1)

# Check if X is within the limit
if X <= 10**9:
    print(X)
else:
    print("inf")

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 473,
  "completion_tokens": 271,
  "gen_seconds": 5.91,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
The problem asks us to calculate the sum of a geometric series \( X = \sum_{i=0}^{M} N^i \) and determine if the result is less than or equal to \( 10^9 \). If the sum exceeds \( 10^9 \), the output should be `inf`.

The formula for the sum of a geometric series is \( X = \frac{N^{M+1} - 1}{N - 1} \) for \( N \neq 1 \). If \( N = 1 \), the sum is simply \( M + 1 \).

We need to ensure that the result of \( X \) is checked against \( 10^9 \) to determine the output.

### Complete Solution
```python
import sys
input = sys.stdin.buffer.readline

def main():
    N, M = map(int, input().split())
    if N == 1:
        X = M + 1
    else:
        X = (N ** (M + 1) - 1) // (N - 1)
    
    if X > 10**9:
        print("inf")
    else:
        print(X)

if __name__ == '__main__':
    main()
```
````

### Extracted final code

````python
import sys
input = sys.stdin.buffer.readline

def main():
    N, M = map(int, input().split())
    if N == 1:
        X = M + 1
    else:
        X = (N ** (M + 1) - 1) // (N - 1)
    
    if X > 10**9:
        print("inf")
    else:
        print(X)

if __name__ == '__main__':
    main()

````

### Test result

````json
null
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 473,
  "completion_tokens": 177,
  "gen_seconds": 3.89,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem asks to compute the sum of a geometric series \(X = \sum_{i=0}^{M} N^i\) and output the result or "inf" if the sum exceeds \(10^9\). Given the constraints, we can safely compute the sum directly using the formula for the sum of a geometric series. If the result exceeds \(10^9\), we output "inf". This solution involves calculating the sum and checking its value against the threshold.
```python
# Read input
N, M = map(int, input().split())

# Compute the sum of the geometric series
X = (N**M - 1) // (N - 1)

# Check the value and print the result
if X > 10**9:
    print('inf')
else:
    print(X)
```
````

### Extracted final code

````python
# Read input
N, M = map(int, input().split())

# Compute the sum of the geometric series
X = (N**M - 1) // (N - 1)

# Check the value and print the result
if X > 10**9:
    print('inf')
else:
    print(X)

````

### Test result

````json
{
  "test_index": 0,
  "input": "7 3",
  "expected": "400",
  "got": "57\n",
  "error": null
}
````
