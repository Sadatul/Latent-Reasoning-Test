# atcoder_abc308_b — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "atcoder_abc308_b",
  "title": "Default Price",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2023-07-01",
  "format": "stdin",
  "prompt_style": 1,
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
Takahashi ate N plates of sushi at a sushi restaurant.  The color of the i-th plate is represented by a string C_i.
The price of a sushi corresponds to the color of the plate.  For each i=1,\ldots,M, the sushi on a plate whose color is represented by a string D_i is worth P_i yen a plate (yen is the currency of Japan).  If the color does not coincide with any of D_1,\ldots, and D_M, it is worth P_0 yen a plate.
Find the total amount of the prices of sushi that Takahashi ate.

Input

The input is given from Standard Input in the following format:
N M
C_1 \ldots C_N
D_1 \ldots D_M
P_0 P_1 \ldots P_M

Output

Print the answer as an integer.

Constraints


- 1\leq N,M\leq 100
- C_i and D_i are strings of length between 1 and 20, inclusive, consisting of lowercase English letters.
- D_1,\ldots, and D_M are distinct.
- 1\leq P_i\leq 10000
- N, M, and P_i are integers.

Sample Input 1

3 2
red green blue
blue red
800 1600 2800

Sample Output 1

5200

A blue plate, red plate, and green plate are worth P_1 = 1600, P_2 = 2800, and P_0 = 800 yen, respectively.
The total amount of the prices of the sushi that he ate is 2800+800+1600=5200 yen.

Sample Input 2

3 2
code queen atcoder
king queen
10 1 1

Sample Output 2

21

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 12,
  "finish_reason": "stop",
  "prompt_tokens": 595,
  "completion_tokens": 236,
  "gen_seconds": 5.21,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to map each color of the sushi plates Takahashi ate to its corresponding price. If the color does not match any of the given colors, the price is `P_0`.

Here's a step-by-step plan:
1. Read and store the colors of the plates Takahashi ate (N plates).
2. Read and store the distinct colors of the plates with their corresponding prices (M plates).
3. Initialize the total price to `P_0`.
4. For each color of the plates Takahashi ate, find its price in the list of prices and add it to the total price.
5. Print the total price.

```python
# Read inputs
N, M = map(int, input().split())
colors_takahashi = input().split()
D = input().split()
P = list(map(int, input().split()))

# Initialize total price
total_price = P[0]

# Calculate total price
for color in colors_takahashi:
    if color in D:
        total_price += P[D.index(color)]
    else:
        total_price += P[0]

print(total_price)
```
````

### Extracted final code

````python
# Read inputs
N, M = map(int, input().split())
colors_takahashi = input().split()
D = input().split()
P = list(map(int, input().split()))

# Initialize total price
total_price = P[0]

# Calculate total price
for color in colors_takahashi:
    if color in D:
        total_price += P[D.index(color)]
    else:
        total_price += P[0]

print(total_price)

````

### Test result

````json
{
  "test_index": 0,
  "input": "3 2\nred green blue\nblue red\n800 1600 2800\n",
  "expected": "5200\n",
  "got": "4000\n",
  "error": null
}
````

## Attempt 2 — RUNTIME_ERROR

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "runtime_error",
  "num_passed": 0,
  "num_tests": 12,
  "finish_reason": "stop",
  "prompt_tokens": 595,
  "completion_tokens": 310,
  "gen_seconds": 6.61,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
Understanding the problem involves mapping the color of each sushi plate to its corresponding price based on the provided dictionary of colors and their prices. If a color does not match any in the dictionary, it is assigned the default price. The total cost is the sum of all prices of the plates Takahashi ate.

### Algorithm:
1. Read the number of plates `N` and the number of colors `M`.
2. Read the colors of the plates `C_1, ..., C_N`.
3. Read the colors and prices from the dictionary `D_1, ..., D_M` and the default price `P_0`.
4. For each plate color `C_i`, find its price in the dictionary or use the default price if it's not found.
5. Sum up the prices to get the total cost.
6. Output the total cost.

### Complete Python Code:
```python
# Read the number of plates and colors
N, M = map(int, input().split())

# Read the colors of the plates
C = [input() for _ in range(N)]

# Read the dictionary of colors and their prices
D = [input().split() for _ in range(M)]
P = {D[i][0]: int(D[i][1]) for i in range(M)}

# Read the default price
P0 = int(input())

# Calculate the total cost
total_cost = sum(P.get(C[i], P0) for i in range(N))

# Output the total cost
print(total_cost)
```
````

### Extracted final code

````python
# Read the number of plates and colors
N, M = map(int, input().split())

# Read the colors of the plates
C = [input() for _ in range(N)]

# Read the dictionary of colors and their prices
D = [input().split() for _ in range(M)]
P = {D[i][0]: int(D[i][1]) for i in range(M)}

# Read the default price
P0 = int(input())

# Calculate the total cost
total_cost = sum(P.get(C[i], P0) for i in range(N))

# Output the total cost
print(total_cost)

````

### Test result

````json
{
  "test_index": 0,
  "input": "3 2\nred green blue\nblue red\n800 1600 2800\n",
  "expected": "5200\n",
  "got": "",
  "error": "Traceback (most recent call last):\n  File \"/tmp/eval_r1qwbmhx/solution.py\", line 33, in <module>\n    D = [input().split() for _ in range(M)]\n         ~~~~~^^\nEOFError: EOF when reading a line\n"
}
````

## Attempt 3 — RUNTIME_ERROR

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "runtime_error",
  "num_passed": 0,
  "num_tests": 12,
  "finish_reason": "stop",
  "prompt_tokens": 595,
  "completion_tokens": 290,
  "gen_seconds": 6.19,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves calculating the total price of sushi plates Takahashi ate based on their colors. Each color corresponds to a specific price, with the default price being `P_0`. The input provides the number of plates, their colors, the distinct colors available for pricing, and the corresponding prices for those colors.

Here's a step-by-step approach:

1. Read the number of plates `N` and the number of distinct colors `M`.
2. Read the list of plate colors `C`.
3. Read the list of distinct colors `D` and their corresponding prices `P`.
4. Read `P_0` (the base price for colors not in `D`).
5. For each plate color `C_i`, if it matches one of the `D` colors, add the corresponding price `P` to the total; otherwise, add `P_0`.

Let's implement this in Python:
```python
N, M = map(int, input().split())
C = [input() for _ in range(N)]
D = [input() for _ in range(M)]
P = list(map(int, input().split())) + [0]  # P0 is handled by the last element in the list
P0 = P[-1]

total_price = 0
for color in C:
    total_price += P[D.index(color)] if color in D else P0

print(total_price)
```
````

### Extracted final code

````python
N, M = map(int, input().split())
C = [input() for _ in range(N)]
D = [input() for _ in range(M)]
P = list(map(int, input().split())) + [0]  # P0 is handled by the last element in the list
P0 = P[-1]

total_price = 0
for color in C:
    total_price += P[D.index(color)] if color in D else P0

print(total_price)

````

### Test result

````json
{
  "test_index": 0,
  "input": "3 2\nred green blue\nblue red\n800 1600 2800\n",
  "expected": "5200\n",
  "got": "",
  "error": "Traceback (most recent call last):\n  File \"/tmp/eval_if86awoe/solution.py\", line 28, in <module>\n    D = [input() for _ in range(M)]\n         ~~~~~^^\nEOFError: EOF when reading a line\n"
}
````
