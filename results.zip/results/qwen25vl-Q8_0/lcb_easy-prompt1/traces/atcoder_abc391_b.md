# atcoder_abc391_b — PASS (3/3 attempts passed)

````json
{
  "id": "atcoder_abc391_b",
  "title": "Seek Grid",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2025-02-01",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 3
}
````

## User prompt

````text
### Question:
You are given an N \times N grid S and an M \times M grid T. The cell at the i-th row from the top and the j-th column from the left is denoted by (i,j).
The colors of the cells in S and T are represented by N^2 characters S_{i,j} (1\leq i,j\leq N) and M^2 characters T_{i,j} (1\leq i,j\leq M), respectively. In grid S, cell (i,j) is white if S_{i,j} is ., and black if S_{i,j} is #. The same applies for grid T.
Find T within S. More precisely, output integers a and b (1 \leq a,b \leq N-M+1) that satisfy the following condition:

- S_{a+i-1,b+j-1} = T_{i,j} for every i,j (1\leq i,j \leq M).

Input

The input is given from Standard Input in the following format:
N M
S_{1,1}S_{1,2}\dots S_{1,N}
S_{2,1}S_{2,2}\dots S_{2,N}
\vdots
S_{N,1}S_{N,2}\dots S_{N,N}
T_{1,1}T_{1,2}\dots T_{1,M}
T_{2,1}T_{2,2}\dots T_{2,M}
\vdots
T_{M,1}T_{M,2}\dots T_{M,M}

Output

Print a and b in this order, separated by a space on one line.

Constraints


- 1 \leq M \leq N \leq 50
- N and M are integers.
- Each of S_{i,j} and T_{i,j} is . or #.
- There is exactly one pair (a,b) satisfying the condition.

Sample Input 1

3 2
#.#
..#
##.
.#
#.

Sample Output 1

2 2

The 2 \times 2 subgrid of S from the 2nd to the 3rd row and from the 2nd to the 3rd column matches T.

Sample Input 2

2 1
#.
##
.

Sample Output 2

1 2

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 42,
  "num_tests": 42,
  "finish_reason": "stop",
  "prompt_tokens": 680,
  "completion_tokens": 307,
  "gen_seconds": 6.84,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to find a subgrid of size `M x M` within the larger grid `N x N` that matches the given `M x M` grid `T`. Here's how we can approach it:

1. Iterate through each possible starting position `(a, b)` in the larger grid.
2. Compare the `M x M` subgrid starting at `(a, b)` with the grid `T`.
3. If the subgrid matches `T`, return the starting position `(a, b)`.

Given the constraints, this approach is feasible since the grid sizes are relatively small (up to 50x50).

Here's the complete solution:

```python
import sys
input = sys.stdin.readline

def solve():
    n, m = map(int, input().split())
    s = [input().strip() for _ in range(n)]
    t = [input().strip() for _ in range(m)]
    m2 = len(t[0])

    for a in range(n - m + 1):
        for b in range(n - m + 1):
            flag = True
            for i in range(m):
                for j in range(m):
                    if t[i][j] != s[a + i][b + j]:
                        flag = False
                        break
                if not flag:
                    break
            if flag:
                print(f"{a + 1} {b + 1}")
                return
solve()
```
````

### Extracted final code

````python
import sys
input = sys.stdin.readline

def solve():
    n, m = map(int, input().split())
    s = [input().strip() for _ in range(n)]
    t = [input().strip() for _ in range(m)]
    m2 = len(t[0])

    for a in range(n - m + 1):
        for b in range(n - m + 1):
            flag = True
            for i in range(m):
                for j in range(m):
                    if t[i][j] != s[a + i][b + j]:
                        flag = False
                        break
                if not flag:
                    break
            if flag:
                print(f"{a + 1} {b + 1}")
                return
solve()

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 42,
  "num_tests": 42,
  "finish_reason": "stop",
  "prompt_tokens": 680,
  "completion_tokens": 280,
  "gen_seconds": 6.09,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
The problem requires finding the top-left corner of a smaller grid `T` within a larger grid `S`. The target is to match the entire `M x M` grid `T` within the `N x N` grid `S`. We can solve this by iterating over each possible starting position in `S` and checking if the subgrid of `S` of size `M x M` matches the grid `T`. The matching can be done by comparing each corresponding element of the two grids.

### Complete Solution:
```python
# Read the input
N, M = map(int, input().split())
S = [input() for _ in range(N)]
T = [input() for _ in range(M)]

# Function to check if the subgrid of S matches T
def is_match(S, T, a, b):
    for i in range(M):
        for j in range(M):
            if S[a + i - 1][b + j - 1] != T[i][j]:
                return False
    return True

# Iterate over all possible starting positions
for a in range(1, N - M + 2):
    for b in range(1, N - M + 2):
        if is_match(S, T, a, b):
            print(a, b)
            break
```
````

### Extracted final code

````python
# Read the input
N, M = map(int, input().split())
S = [input() for _ in range(N)]
T = [input() for _ in range(M)]

# Function to check if the subgrid of S matches T
def is_match(S, T, a, b):
    for i in range(M):
        for j in range(M):
            if S[a + i - 1][b + j - 1] != T[i][j]:
                return False
    return True

# Iterate over all possible starting positions
for a in range(1, N - M + 2):
    for b in range(1, N - M + 2):
        if is_match(S, T, a, b):
            print(a, b)
            break

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 42,
  "num_tests": 42,
  "finish_reason": "stop",
  "prompt_tokens": 680,
  "completion_tokens": 293,
  "gen_seconds": 6.43,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to find the starting position (a, b) in the grid S where a subgrid of size M x M matches the grid T. We iterate over all possible starting positions within the grid S and check if the corresponding subgrid matches T.

Here's the step-by-step approach:

1. Iterate over all possible starting positions (a, b) in the grid S.
2. Extract the subgrid of size M x M starting from position (a, b).
3. Compare the extracted subgrid with T.
4. If a match is found, return the starting position (a, b).

Let's implement this solution.
```python
# Read input
N, M = map(int, input().split())
S = [input() for _ in range(N)]
T = [input() for _ in range(M)]

# Check if a subgrid starting at (a, b) matches T
def check_subgrid(a, b):
    for i in range(M):
        for j in range(M):
            if S[a+i-1][b+j-1] != T[i][j]:
                return False
    return True

# Find the starting position (a, b)
for a in range(1, N-M+2):
    for b in range(1, N-M+2):
        if check_subgrid(a, b):
            print(a, b)
            break
```
````

### Extracted final code

````python
# Read input
N, M = map(int, input().split())
S = [input() for _ in range(N)]
T = [input() for _ in range(M)]

# Check if a subgrid starting at (a, b) matches T
def check_subgrid(a, b):
    for i in range(M):
        for j in range(M):
            if S[a+i-1][b+j-1] != T[i][j]:
                return False
    return True

# Find the starting position (a, b)
for a in range(1, N-M+2):
    for b in range(1, N-M+2):
        if check_subgrid(a, b):
            print(a, b)
            break

````

### Test result

````json
null
````
