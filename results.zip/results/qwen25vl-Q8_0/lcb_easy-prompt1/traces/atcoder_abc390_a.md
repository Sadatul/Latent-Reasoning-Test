# atcoder_abc390_a — PASS (2/3 attempts passed)

````json
{
  "id": "atcoder_abc390_a",
  "title": "12435",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2025-01-25",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 2
}
````

## User prompt

````text
### Question:
You are given an integer sequence A=(A_1,A_2,A_3,A_4,A_5) obtained by permuting (1,2,3,4,5).
Determine whether A can be sorted in ascending order by performing exactly one operation of swapping two adjacent elements in A.

Input

The input is given from Standard Input in the following format:
A_1 A_2 A_3 A_4 A_5

Output

If A can be sorted in ascending order by exactly one operation, print Yes; otherwise, print No.

Constraints


- A is an integer sequence of length 5 obtained by permuting (1,2,3,4,5).

Sample Input 1

1 2 4 3 5

Sample Output 1

Yes

By swapping A_3 and A_4, A becomes (1,2,3,4,5), so it can be sorted in ascending order. Therefore, print Yes.

Sample Input 2

5 3 2 4 1

Sample Output 2

No

No matter what operation is performed, it is impossible to sort A in ascending order.

Sample Input 3

1 2 3 4 5

Sample Output 3

No

You must perform exactly one operation.

Sample Input 4

2 1 3 4 5

Sample Output 4

Yes

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 2,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 466,
  "completion_tokens": 243,
  "gen_seconds": 5.33,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if we can sort the given sequence by swapping exactly two adjacent elements. Here's the approach:

1. **Identify the Out-of-Order Elements**: Check which elements are out of the sorted order (1, 2, 3, 4, 5).
2. **Check for Exactly Two Out-of-Order Elements**: Only two elements should be out of order for one swap to sort the sequence.
3. **Check the Positions of Out-of-Order Elements**: Ensure that swapping these two elements can bring the sequence to the sorted order.

Let's implement this logic:
```python
def can_sort_by_one_swap(a):
    # Check for exactly two out-of-order elements
    count = 0
    for i in range(4):
        if a[i] != i + 1:
            count += 1
        if count > 2:
            return False
    return True

def main():
    a = list(map(int, input().split()))
    if can_sort_by_one_swap(a):
        print("Yes")
    else:
        print("No")

if __name__ == "__main__":
    main()
```
````

### Extracted final code

````python
def can_sort_by_one_swap(a):
    # Check for exactly two out-of-order elements
    count = 0
    for i in range(4):
        if a[i] != i + 1:
            count += 1
        if count > 2:
            return False
    return True

def main():
    a = list(map(int, input().split()))
    if can_sort_by_one_swap(a):
        print("Yes")
    else:
        print("No")

if __name__ == "__main__":
    main()

````

### Test result

````json
{
  "test_index": 2,
  "input": "1 2 3 4 5",
  "expected": "No",
  "got": "Yes\n",
  "error": null
}
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 466,
  "completion_tokens": 296,
  "gen_seconds": 6.41,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To determine if the sequence `A` can be sorted in ascending order by performing exactly one swap of adjacent elements, we need to check if the sequence is almost sorted. Specifically, we need to look for a sequence that is in ascending order except for one pair of adjacent elements that are out of order. We can do this by iterating through the sequence and checking if any two adjacent elements are out of order.

- If the sequence is already sorted, return `No`.
- If a pair of adjacent elements is found that is out of order, try swapping them. If the sequence can be sorted by this swap, return `Yes`.
- If no such pair is found, return `No`.

### Complete Solution
```python
def is_sortable_by_one_swap(a):
    n = len(a)
    for i in range(n-1):
        if a[i] > a[i+1]:
            # Swap the elements to check if the sequence can be sorted
            a[i], a[i+1] = a[i+1], a[i]
            if a == sorted(a):
                return "Yes"
            # Swap back to the original state
            a[i], a[i+1] = a[i+1], a[i]
    return "No"

# Reading the input
a = list(map(int, input().split()))

# Check the sequence and print the result
print(is_sortable_by_one_swap(a))
```
````

### Extracted final code

````python
def is_sortable_by_one_swap(a):
    n = len(a)
    for i in range(n-1):
        if a[i] > a[i+1]:
            # Swap the elements to check if the sequence can be sorted
            a[i], a[i+1] = a[i+1], a[i]
            if a == sorted(a):
                return "Yes"
            # Swap back to the original state
            a[i], a[i+1] = a[i+1], a[i]
    return "No"

# Reading the input
a = list(map(int, input().split()))

# Check the sequence and print the result
print(is_sortable_by_one_swap(a))

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 466,
  "completion_tokens": 244,
  "gen_seconds": 5.34,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem asks us to determine if a given permutation of the numbers 1 through 5 can be sorted in ascending order by performing exactly one swap of two adjacent elements. To solve this, we need to check how many inversions (pairs of elements that are out of order) there are and see if there is exactly one pair that needs to be swapped to sort the sequence. If there is exactly one inversion, it means we can sort the sequence by swapping those two elements.

Here's the Python code to solve this:

```python
def count_inversions(sequence):
    inversions = 0
    for i in range(1, len(sequence)):
        for j in range(i):
            if sequence[j] > sequence[i]:
                inversions += 1
    return inversions

def is_sortable(sequence):
    inversions = count_inversions(sequence)
    if inversions == 1:
        return True
    return False

# Reading the input
input_sequence = list(map(int, input().split()))

# Using the function to check if the sequence can be sorted with exactly one swap
if is_sortable(input_sequence):
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
def count_inversions(sequence):
    inversions = 0
    for i in range(1, len(sequence)):
        for j in range(i):
            if sequence[j] > sequence[i]:
                inversions += 1
    return inversions

def is_sortable(sequence):
    inversions = count_inversions(sequence)
    if inversions == 1:
        return True
    return False

# Reading the input
input_sequence = list(map(int, input().split()))

# Using the function to check if the sequence can be sorted with exactly one swap
if is_sortable(input_sequence):
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````
