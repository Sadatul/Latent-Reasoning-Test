# atcoder_abc367_a — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "atcoder_abc367_a",
  "title": "Shout Everyday",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-08-17",
  "format": "stdin",
  "prompt_style": 1,
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
In the Kingdom of AtCoder, residents are required to shout their love for takoyaki at A o'clock every day.
Takahashi, who lives in the Kingdom of AtCoder, goes to bed at B o'clock and wakes up at C o'clock every day (in the 24-hour clock). He can shout his love for takoyaki when he is awake, but cannot when he is asleep. Determine whether he can shout his love for takoyaki every day. Here, a day has 24 hours, and his sleeping time is less than 24 hours.

Input

The input is given from Standard Input in the following format:
A B C

Output

Print Yes if Takahashi can shout his love for takoyaki every day, and No otherwise.

Constraints


- 0\leq A,B,C\lt 24
- A, B, and C are pairwise different.
- All input values are integers.

Sample Input 1

21 8 14

Sample Output 1

Yes

Takahashi goes to bed at 8 o'clock and wakes up at 14 o'clock every day. He is awake at 21 o'clock, so he can shout his love for takoyaki every day. Therefore, print Yes.

Sample Input 2

0 21 7

Sample Output 2

No

Takahashi goes to bed at 21 o'clock and wakes up at 7 o'clock every day. He is not awake at 0 o'clock, so he cannot shout his love for takoyaki every day. Therefore, print No.

Sample Input 3

10 7 17

Sample Output 3

No

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 530,
  "completion_tokens": 215,
  "gen_seconds": 4.88,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine if Takahashi can shout his love for takoyaki every day based on his sleeping and waking times. Here's a step-by-step approach:

1. Extract the sleeping time (B) and the waking time (C) from the input.
2. Calculate the duration from B to C to determine when Takahashi is awake each day.
3. Compare the times A (when Takahashi is supposed to shout) with the times he is awake to see if they overlap.
4. If A falls within the awake period, print 'Yes'; otherwise, print 'No'.

Let's implement this logic in the code.
```python
# Read the input
A, B, C = map(int, input().split())

# Define the awake period
awake_start = min(B, C)
awake_end = max(B, C)

# Check if A falls within the awake period
if A >= awake_start and A < awake_end:
    print('Yes')
else:
    print('No')
```
````

### Extracted final code

````python
# Read the input
A, B, C = map(int, input().split())

# Define the awake period
awake_start = min(B, C)
awake_end = max(B, C)

# Check if A falls within the awake period
if A >= awake_start and A < awake_end:
    print('Yes')
else:
    print('No')

````

### Test result

````json
{
  "test_index": 0,
  "input": "21 8 14\n",
  "expected": "Yes\n",
  "got": "No\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 2,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 530,
  "completion_tokens": 147,
  "gen_seconds": 3.27,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To determine if Takahashi can shout his love for takoyaki every day, we need to check if the time he goes to bed (B) is before the time he wakes up (C). If it is, he will be awake at A o'clock. If not, he will be asleep and unable to shout at A o'clock. Since the problem implies A is when he wants to shout, the condition to check is B <= C.

```python
# Read the input
A, B, C = map(int, input().split())

# Check if B is less than or equal to C
if B <= C:
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
# Read the input
A, B, C = map(int, input().split())

# Check if B is less than or equal to C
if B <= C:
    print("Yes")
else:
    print("No")

````

### Test result

````json
{
  "test_index": 2,
  "input": "10 7 17\n",
  "expected": "No\n",
  "got": "Yes\n",
  "error": null
}
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 530,
  "completion_tokens": 202,
  "gen_seconds": 4.47,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem requires us to determine if Takahashi can shout his love for takoyaki every day given his sleep schedule. We need to check if the time \(A\) he goes to shout (21:00 in the sample input) falls within the awake period (which is from \(B\) to \(C\)). If \(A\) is within the awake period, he can shout every day; otherwise, he cannot.

Given the constraints and the pairwise different \(A\), \(B\), and \(C\) values, we can directly compare \(A\) with the awake period \([B, C]\).
```python
# Read input
A, B, C = map(int, input().split())

# Check if A is within the awake period
is_awake_at_shout_time = B <= A <= C

# Output the result
if is_awake_at_shout_time:
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
# Read input
A, B, C = map(int, input().split())

# Check if A is within the awake period
is_awake_at_shout_time = B <= A <= C

# Output the result
if is_awake_at_shout_time:
    print("Yes")
else:
    print("No")

````

### Test result

````json
{
  "test_index": 0,
  "input": "21 8 14\n",
  "expected": "Yes\n",
  "got": "No\n",
  "error": null
}
````
