# atcoder_abc321_a — PASS (2/3 attempts passed)

````json
{
  "id": "atcoder_abc321_a",
  "title": "321",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2023-09-23",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 2
}
````

## User prompt

````text
### Question:
A positive integer x is called a 321-like Number when it satisfies the following condition.

- The digits of x are strictly decreasing from top to bottom.
- In other words, if x has d digits, it satisfies the following for every integer i such that 1 \le i < d:
- (the i-th digit from the top of x) > (the (i+1)-th digit from the top of x).



Note that all one-digit positive integers are 321-like Numbers.
For example, 321, 96410, and 1 are 321-like Numbers, but 123, 2109, and 86411 are not.
You are given N as input. Print Yes if N is a 321-like Number, and No otherwise.

Input

The input is given from Standard Input in the following format:
N

Output

Print Yes if N is a 321-like Number, and No otherwise.

Constraints


- All input values are integers.
- 1 \le N \le 99999

Sample Input 1

321

Sample Output 1

Yes

For N=321, the following holds:

- The first digit from the top, 3, is greater than the second digit from the top, 2.
- The second digit from the top, 2, is greater than the third digit from the top, 1.

Thus, 321 is a 321-like Number.

Sample Input 2

123

Sample Output 2

No

For N=123, the following holds:

- The first digit from the top, 1, is not greater than the second digit from the top, 2.

Thus, 123 is not a 321-like Number.

Sample Input 3

1

Sample Output 3

Yes

Sample Input 4

86411

Sample Output 4

No

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 599,
  "completion_tokens": 140,
  "gen_seconds": 3.13,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if the given number `N` is strictly decreasing from left to right. We can achieve this by converting the number to a string, then comparing each digit with the next one to ensure the digits are in a strictly decreasing order.

```python
n = int(input())
num_str = str(n)
length = len(num_str)
is_321_like = True

for i in range(1, length):
    if num_str[i] < num_str[i-1]:
        is_321_like = False
        break

if is_321_like:
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
n = int(input())
num_str = str(n)
length = len(num_str)
is_321_like = True

for i in range(1, length):
    if num_str[i] < num_str[i-1]:
        is_321_like = False
        break

if is_321_like:
    print("Yes")
else:
    print("No")

````

### Test result

````json
{
  "test_index": 0,
  "input": "321\n",
  "expected": "Yes\n",
  "got": "No\n",
  "error": null
}
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 16,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 599,
  "completion_tokens": 244,
  "gen_seconds": 5.13,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To determine if a given number `N` is a 321-like number, we need to check if the digits of `N` are strictly decreasing from the left to the right. A number is considered 321-like if each digit is greater than the digit immediately to its right. This can be verified by converting the number to a string and comparing each digit with the next one.

### Solution:
1. Convert the input number `N` to a string to easily access each digit.
2. Compare each digit with the next one to check if the digits are strictly decreasing.
3. If all digits are in strictly decreasing order, print "Yes". Otherwise, print "No".

```python
# Read the input
N = input()

# Convert the number to a list of its digits
digits = [int(digit) for digit in N]

# Check if the digits are strictly decreasing
is_321_like = all(digits[i] > digits[i+1] for i in range(len(digits) - 1))

# Print the result
if is_321_like:
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
# Read the input
N = input()

# Convert the number to a list of its digits
digits = [int(digit) for digit in N]

# Check if the digits are strictly decreasing
is_321_like = all(digits[i] > digits[i+1] for i in range(len(digits) - 1))

# Print the result
if is_321_like:
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 16,
  "num_tests": 16,
  "finish_reason": "stop",
  "prompt_tokens": 599,
  "completion_tokens": 205,
  "gen_seconds": 4.34,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem requires checking if a given number is a 321-like number. A 321-like number is defined as a number where the digits are strictly decreasing from left to right. We can solve this by iterating through the digits of the number and ensuring each digit is greater than the next one.

Let's break down the steps:
1. Convert the number to a string to easily iterate through its digits.
2. Compare each digit with the next one to ensure they are in decreasing order.
3. If all digits satisfy this condition, print 'Yes', otherwise print 'No'.

```python
# Read the number N from standard input
N = int(input())

# Convert the number to a string to iterate through its digits
N_str = str(N)

# Check if the digits of N are strictly decreasing
if all(N_str[i] > N_str[i+1] for i in range(len(N_str) - 1)):
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
# Read the number N from standard input
N = int(input())

# Convert the number to a string to iterate through its digits
N_str = str(N)

# Check if the digits of N are strictly decreasing
if all(N_str[i] > N_str[i+1] for i in range(len(N_str) - 1)):
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````
