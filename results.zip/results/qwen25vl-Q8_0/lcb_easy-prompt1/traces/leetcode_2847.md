# leetcode_2847 — PASS (3/3 attempts passed)

````json
{
  "id": "leetcode_2847",
  "title": "find-maximum-number-of-string-pairs",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "leetcode",
  "difficulty": "easy",
  "contest_date": "2023-06-24",
  "format": "functional",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 3
}
````

## User prompt

````text
### Question:
You are given a 0-indexed array words consisting of distinct strings.
The string words[i] can be paired with the string words[j] if:

The string words[i] is equal to the reversed string of words[j].
0 <= i < j < words.length.

Return the maximum number of pairs that can be formed from the array words.
Note that each string can belong in at most one pair.
 
Example 1:

Input: words = ["cd","ac","dc","ca","zz"]
Output: 2
Explanation: In this example, we can form 2 pair of strings in the following way:
- We pair the 0^th string with the 2^nd string, as the reversed string of word[0] is "dc" and is equal to words[2].
- We pair the 1^st string with the 3^rd string, as the reversed string of word[1] is "ca" and is equal to words[3].
It can be proven that 2 is the maximum number of pairs that can be formed.
Example 2:

Input: words = ["ab","ba","cc"]
Output: 1
Explanation: In this example, we can form 1 pair of strings in the following way:
- We pair the 0^th string with the 1^st string, as the reversed string of words[1] is "ab" and is equal to words[0].
It can be proven that 1 is the maximum number of pairs that can be formed.

Example 3:

Input: words = ["aa","ab"]
Output: 0
Explanation: In this example, we are unable to form any pair of strings.

 
Constraints:

1 <= words.length <= 50
words[i].length == 2
words consists of distinct strings.
words[i] contains only lowercase English letters.

### Format: You will use the following starter code to write the solution to the problem and enclose your code within delimiters.
```python
class Solution:
    def maximumNumberOfStringPairs(self, words: List[str]) -> int:
        
```

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 15,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 574,
  "completion_tokens": 197,
  "gen_seconds": 4.52,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to find the maximum number of pairs of strings in the array `words` such that each string in a pair is the reverse of the other. Here's the plan:

1. Iterate through the list of words.
2. For each word at index `i`, check if there exists another word in the list starting from `i+1` whose reverse matches the original word at index `i`.
3. Count the pairs found.
4. Return the count of pairs.

Let's implement this logic:

```python
from collections import defaultdict

class Solution:
    def maximumNumberOfStringPairs(self, words: List[str]) -> int:
        count = 0
        reversed_word_map = defaultdict(list)
        
        for i, word in enumerate(words):
            reversed_word = word[::-1]
            if reversed_word in reversed_word_map:
                count += 1
            reversed_word_map[word].append(i)
        
        return count
```
````

### Extracted final code

````python
from collections import defaultdict

class Solution:
    def maximumNumberOfStringPairs(self, words: List[str]) -> int:
        count = 0
        reversed_word_map = defaultdict(list)
        
        for i, word in enumerate(words):
            reversed_word = word[::-1]
            if reversed_word in reversed_word_map:
                count += 1
            reversed_word_map[word].append(i)
        
        return count

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 15,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 574,
  "completion_tokens": 191,
  "gen_seconds": 4.23,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Reasoning:

The problem requires us to find the maximum number of pairs of strings in an array such that one string is the reverse of the other. Given the constraints, it's efficient to use a set to keep track of the reversed strings we have encountered so far. For each word, we check if its reverse is in the set, if so, we count it as a pair and remove it from the set to ensure each string is only used once. Finally, we return the count of pairs.

### Complete Solution:

```python
class Solution:
    def maximumNumberOfStringPairs(self, words: List[str]) -> int:
        max_pairs = 0
        seen = set()
        
        for word in words:
            reversed_word = word[::-1]
            if reversed_word in seen:
                max_pairs += 1
                seen.remove(reversed_word)
            else:
                seen.add(word)
        
        return max_pairs
```
````

### Extracted final code

````python
class Solution:
    def maximumNumberOfStringPairs(self, words: List[str]) -> int:
        max_pairs = 0
        seen = set()
        
        for word in words:
            reversed_word = word[::-1]
            if reversed_word in seen:
                max_pairs += 1
                seen.remove(reversed_word)
            else:
                seen.add(word)
        
        return max_pairs

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 15,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 574,
  "completion_tokens": 250,
  "gen_seconds": 5.52,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves finding the maximum number of pairs of strings in the array `words` where each pair consists of a string and its reverse. Since the strings are distinct and each string can be part of at most one pair, we can use a set to track which strings have been paired.

Here's the strategy:
1. Initialize a counter for the number of pairs.
2. Use a set to keep track of strings that have been paired.
3. Iterate through the list of words:
   - For each word, check if its reverse exists in the set.
   - If it does, increment the counter and remove the word/its reverse from the set.
   - Otherwise, add the word to the set.
4. Return the counter.

This ensures that each word is only used once, and the maximum number of pairs is counted.

```python
class Solution:
    def maximumNumberOfStringPairs(self, words: List[str]) -> int:
        pairs = 0
        seen = set()
        
        for word in words:
            reverse_word = word[::-1]
            if reverse_word in seen:
                pairs += 1
                seen.remove(reverse_word)
            else:
                seen.add(word)
        
        return pairs
```
````

### Extracted final code

````python
class Solution:
    def maximumNumberOfStringPairs(self, words: List[str]) -> int:
        pairs = 0
        seen = set()
        
        for word in words:
            reverse_word = word[::-1]
            if reverse_word in seen:
                pairs += 1
                seen.remove(reverse_word)
            else:
                seen.add(word)
        
        return pairs

````

### Test result

````json
null
````
