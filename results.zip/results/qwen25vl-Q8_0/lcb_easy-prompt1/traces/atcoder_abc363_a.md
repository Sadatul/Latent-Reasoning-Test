# atcoder_abc363_a — PASS (1/3 attempts passed)

````json
{
  "id": "atcoder_abc363_a",
  "title": "Piling Up",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-07-20",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 1
}
````

## User prompt

````text
### Question:
In AtCoder, a user's rating is given as a positive integer, and based on this value, a certain number of ^ is displayed.
Specifically, when the rating is between 1 and 399, inclusive, the display rules are as follows:

- When the rating is between 1 and 99, inclusive, ^ is displayed once.
- When the rating is between 100 and 199, inclusive, ^ is displayed twice.
- When the rating is between 200 and 299, inclusive, ^ is displayed three times.
- When the rating is between 300 and 399, inclusive, ^ is displayed four times.

Currently, Takahashi's rating is R. Here, it is guaranteed that R is an integer between 1 and 299, inclusive.
Find the minimum increase in rating required for him to increase the number of displayed ^.
It can be proved that under the constraints of this problem, he can increase the number of ^ without raising his rating to 400 or above.

Input

The input is given from Standard Input in the following format:
R

Output

Print, as an integer, the minimum increase in rating required for Takahashi to increase the number of displayed ^.

Constraints


- 1 \leq R \leq 299
- R is an integer.

Sample Input 1

123

Sample Output 1

77

Takahashi's current rating is 123, and ^ is displayed twice.
By increasing his rating by 77, his rating will become 200, and ^ will be displayed three times.
When the rating is 199 or below, ^ is displayed not more than twice, so print 77.

Sample Input 2

250

Sample Output 2

50

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 2,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 565,
  "completion_tokens": 405,
  "gen_seconds": 9.07,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine the minimum increase in Takahashi's rating that will change the number of displayed `^` from the current display to the next higher display. Given the rating ranges, we can deduce the following:

- From 1 to 99, `^` is displayed once.
- From 100 to 199, `^` is displayed twice.
- From 200 to 299, `^` is displayed three times.

We need to find the minimum rating increase that will move from the current display level to the next higher level. For example, if Takahashi's current rating is 123 (displaying `^` twice), he needs to increase his rating to 200 (displaying `^` three times). The difference is 200 - 123 = 77.

Here’s the step-by-step algorithm:
1. Read the current rating \( R \).
2. Determine the current display level based on the rating \( R \).
3. Calculate the minimum increase required to move to the next higher display level.

Let's implement this logic.

```python
# Read the current rating from the input
R = int(input())

# Determine the current display level based on the rating
if R <= 99:
    next_level_rating = 200  # 100 to 199
    increase = next_level_rating - R
elif 100 <= R <= 199:
    next_level_rating = 200  # 200 to 299
    increase = next_level_rating - R
elif 200 <= R <= 299:
    next_level_rating = 300  # 300 to 399
    increase = next_level_rating - R

# Output the minimum increase required
print(increase)
```
````

### Extracted final code

````python
# Read the current rating from the input
R = int(input())

# Determine the current display level based on the rating
if R <= 99:
    next_level_rating = 200  # 100 to 199
    increase = next_level_rating - R
elif 100 <= R <= 199:
    next_level_rating = 200  # 200 to 299
    increase = next_level_rating - R
elif 200 <= R <= 299:
    next_level_rating = 300  # 300 to 399
    increase = next_level_rating - R

# Output the minimum increase required
print(increase)

````

### Test result

````json
{
  "test_index": 2,
  "input": "99\n",
  "expected": "1\n",
  "got": "101\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 565,
  "completion_tokens": 455,
  "gen_seconds": 9.99,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
The problem requires determining the minimum increase in rating needed for Takahashi to increase the number of displayed `^` from the current rating `R`. The rating `R` is given and it is guaranteed to be between 1 and 299. Based on the rating range, the number of `^` displayed changes as follows:
- For ratings between 1 and 99, `^` is displayed once.
- For ratings between 100 and 199, `^` is displayed twice.
- For ratings between 200 and 299, `^` is displayed three times.

To increase the number of `^` displayed from `R` to the next higher number, we need to find the smallest increase in rating such that the new rating falls into the next higher range. Given the constraints, the only way to increase the number of `^` is to move from a range where `^` is displayed two times to a range where `^` is displayed three times, or vice versa.

The minimum increase required to move from a range where `^` is displayed `n` times to a range where `^` is displayed `n+1` times is the difference between the upper limit of the next range and the current rating. For example, to move from 199 (two `^`) to 200 (three `^`), the increase is 200 - 199 = 1. But since the problem states that the current rating `R` is between 1 and 299, it's clear that the only possible increase is to the next higher range.

Given `R` is between 1 and 299, the minimum increase needed is simply the difference between the upper limit of the next higher range and `R`. This can be calculated as `300 - R` if `R` is in the range 1 to 299, which will ensure `R` moves to the next higher range where `^` is displayed three times.

### Complete Solution Code:
```python
R = int(input())
print(300 - R)
```
````

### Extracted final code

````python
R = int(input())
print(300 - R)

````

### Test result

````json
{
  "test_index": 0,
  "input": "123\n",
  "expected": "77\n",
  "got": "177\n",
  "error": null
}
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 14,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 565,
  "completion_tokens": 355,
  "gen_seconds": 7.82,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves determining the minimum increase in rating required for Takahashi to increase the number of displayed `^` symbols. Given the rating range and the corresponding `^` display patterns, we need to find out the difference between the current rating and the next threshold where the `^` display increases.

Here's how we can solve it:

1. Identify the current rating, `R`.
2. Determine the next threshold where the `^` display increases based on the rating range.
3. Calculate the difference between the next threshold and the current rating.

Given that the rating ranges are:
- 1 to 99, `^` displayed once.
- 100 to 199, `^` displayed twice.
- 200 to 299, `^` displayed three times.
- 300 to 399, `^` displayed four times.

For `R` in the range 1 to 99, the next threshold is 100.
For `R` in the range 100 to 199, the next threshold is 200.
For `R` in the range 200 to 299, the next threshold is 300.

We can use a simple if-else structure to determine the next threshold and calculate the required increase.

```python
R = int(input())
if 1 <= R <= 99:
    next_threshold = 100
elif 100 <= R <= 199:
    next_threshold = 200
else:
    next_threshold = 300
increase_needed = next_threshold - R
print(increase_needed)
```
````

### Extracted final code

````python
R = int(input())
if 1 <= R <= 99:
    next_threshold = 100
elif 100 <= R <= 199:
    next_threshold = 200
else:
    next_threshold = 300
increase_needed = next_threshold - R
print(increase_needed)

````

### Test result

````json
null
````
