# atcoder_abc349_b — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "atcoder_abc349_b",
  "title": "Commencement",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-04-13",
  "format": "stdin",
  "prompt_style": 1,
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
A string S consisting of lowercase English letters is a good string if and only if it satisfies the following property for all integers i not less than 1:

- There are exactly zero or exactly two different letters that appear exactly i times in S.

Given a string S, determine if it is a good string.

Input

The input is given from Standard Input in the following format:
S

Output

Print Yes if S is a good string, and No otherwise.

Constraints


- S is a string of lowercase English letters with a length between 1 and 100, inclusive.

Sample Input 1

commencement

Sample Output 1

Yes

For the string commencement, the number of different letters that appear exactly i times is as follows:

- i=1: two letters (o and t)
- i=2: two letters (c and n)
- i=3: two letters (e and m)
- i\geq 4: zero letters

Therefore, commencement satisfies the condition of a good string.

Sample Input 2

banana

Sample Output 2

No

For the string banana, there is only one letter that appears exactly one time, which is b, so it does not satisfy the condition of a good string.

Sample Input 3

ab

Sample Output 3

Yes

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 17,
  "finish_reason": "stop",
  "prompt_tokens": 444,
  "completion_tokens": 275,
  "gen_seconds": 6.17,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if the input string `S` meets the criteria for being a "good string". Specifically, for every integer `i` (where `i >= 1`), there should be exactly zero or exactly two different letters that appear exactly `i` times in `S`.

Here's a step-by-step strategy:
1. **Count Frequency of Each Character**: Use a dictionary to count how many times each character appears in the string.
2. **Count Occurrences of Each Frequency**: Use another dictionary to count how many characters appear `i` times for each `i`.
3. **Validate the Conditions**: Ensure that for each `i`, the number of different letters that appear exactly `i` times is either 0 or 2.

Here’s the implementation in Python:
```python
from collections import Counter

def is_good_string(S):
    char_count = Counter(S)
    freq_count = Counter(char_count.values())
    
    for i in range(1, len(S) + 1):
        if i not in freq_count:
            if i == 1 or i == 2:
                continue
            else:
                return 'No'
        if freq_count[i] > 2:
            return 'No'
    return 'Yes'

S = input().strip()
print(is_good_string(S))
```
````

### Extracted final code

````python
from collections import Counter

def is_good_string(S):
    char_count = Counter(S)
    freq_count = Counter(char_count.values())
    
    for i in range(1, len(S) + 1):
        if i not in freq_count:
            if i == 1 or i == 2:
                continue
            else:
                return 'No'
        if freq_count[i] > 2:
            return 'No'
    return 'Yes'

S = input().strip()
print(is_good_string(S))

````

### Test result

````json
{
  "test_index": 0,
  "input": "commencement\n",
  "expected": "Yes\n",
  "got": "No\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 17,
  "finish_reason": "stop",
  "prompt_tokens": 444,
  "completion_tokens": 300,
  "gen_seconds": 6.61,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
### Brief Reasoning:
To determine if a string `S` is a good string, we need to check the frequency of each letter in the string. Specifically, for each integer `i` from 1 to the length of the string, we need to verify that there are exactly zero or exactly two different letters that appear exactly `i` times. We can achieve this by counting the occurrences of each letter and then checking the counts of these occurrences.

1. Use a dictionary to count the frequency of each letter in the string.
2. For each frequency `i` from 1 to the length of the string, count how many different letters appear exactly `i` times.
3. If for any `i`, there are not exactly zero or exactly two different letters, then the string is not a good string.
4. If all checks pass, the string is a good string.

### Complete Solution:
```python
from collections import Counter

def is_good_string(S):
    letter_counts = Counter(S)
    for i in range(1, len(S) + 1):
        if len(list(letter_counts.values())) != 2:
            return "No"
        if i not in letter_counts:
            return "No"
        count_i = len([c for c in letter_counts if letter_counts[c] == i])
        if count_i > 2:
            return "No"
    return "Yes"

S = input().strip()
print(is_good_string(S))
```
````

### Extracted final code

````python
from collections import Counter

def is_good_string(S):
    letter_counts = Counter(S)
    for i in range(1, len(S) + 1):
        if len(list(letter_counts.values())) != 2:
            return "No"
        if i not in letter_counts:
            return "No"
        count_i = len([c for c in letter_counts if letter_counts[c] == i])
        if count_i > 2:
            return "No"
    return "Yes"

S = input().strip()
print(is_good_string(S))

````

### Test result

````json
{
  "test_index": 0,
  "input": "commencement\n",
  "expected": "Yes\n",
  "got": "No\n",
  "error": null
}
````

## Attempt 3 — RUNTIME_ERROR

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "runtime_error",
  "num_passed": 0,
  "num_tests": 17,
  "finish_reason": "stop",
  "prompt_tokens": 444,
  "completion_tokens": 322,
  "gen_seconds": 7.1,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
<brief reasoning>
The problem requires us to check if a given string `S` is a good string. A string `S` is considered good if for every integer `i`, there are exactly zero or exactly two different letters that appear exactly `i` times in `S`. To solve this, we will count the frequency of each letter in the string and then verify the condition for all possible frequencies.

We will count the frequency of each letter using a dictionary. Then, we will iterate through all possible frequencies (1 to the maximum frequency found in the string) and check if there are exactly zero or exactly two different letters in the string that appear exactly `i` times. If this condition is met for all `i`, then the string is good; otherwise, it is not.
```python
<complete solution code>
```python
from collections import Counter

# Read the input string
S = input()

# Count the frequency of each letter in the string
freq = Counter(S)

# Initialize a boolean variable to check if the string is good
is_good = True

# Iterate through all possible frequencies (from 1 to max frequency)
for i in range(1, max(freq.values()) + 1):
    # Check if there are exactly zero or exactly two different letters with frequency i
    if len([key for key, value in freq.items() if value == i]) not in {0, 2}:
        is_good = False
        break

# Print the result
if is_good:
    print("Yes")
else:
    print("No")
````

### Extracted final code

````python
<complete solution code>

````

### Test result

````json
{
  "test_index": 0,
  "input": "commencement\n",
  "expected": "Yes\n",
  "got": "",
  "error": "  File \"/tmp/eval_y1ko3iid/solution.py\", line 26\n    <complete solution code>\n    ^\nSyntaxError: invalid syntax\n"
}
````
