# atcoder_abc337_a — PASS (3/3 attempts passed)

````json
{
  "id": "atcoder_abc337_a",
  "title": "Scoreboard",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-01-20",
  "format": "stdin",
  "prompt_style": 1,
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 3
}
````

## User prompt

````text
### Question:
Team Takahashi and Team Aoki played N matches.
In the i-th match (1\leq i\leq N), Team Takahashi scored X _ i points, and Team Aoki scored Y _ i points.
The team with the higher total score from the N matches wins.
Print the winner.
If the two teams have the same total score, it is a draw.

Input

The input is given from Standard Input in the following format:
N
X _ 1 Y _ 1
X _ 2 Y _ 2
\vdots
X _ N Y _ N

Output

If Team Takahashi wins, print Takahashi; if Team Aoki wins, print Aoki; if it is a draw, print Draw.

Constraints


- 1\leq N\leq 100
- 0\leq X _ i\leq 100\ (1\leq i\leq N)
- 0\leq Y _ i\leq 100\ (1\leq i\leq N)
- All input values are integers.

Sample Input 1

4
10 2
10 1
10 2
3 2

Sample Output 1

Takahashi

In four matches, Team Takahashi scored 33 points, and Team Aoki scored 7 points.
Team Takahashi wins, so print Takahashi.

Sample Input 2

6
5 4
4 5
2 4
1 6
7 1
3 2

Sample Output 2

Draw

Both teams scored 22 points.
It is a draw, so print Draw.

Sample Input 3

4
0 0
10 10
50 50
0 100

Sample Output 3

Aoki

One or both teams may score no points in a match.

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

Think through the problem briefly: work out an algorithm and check it against the examples. Keep this reasoning short. Then you MUST write your complete solution as a single ```python code block at the end of your answer. Only that code block is graded: an answer without it scores zero, so never stop before writing it. Do not give the answer as plain text or in \boxed{}.

Use exactly this format:
<brief reasoning>
```python
<complete solution code>
```
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 13,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 585,
  "completion_tokens": 234,
  "gen_seconds": 5.05,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to calculate the total scores for both teams and compare them. Here's the step-by-step algorithm:

1. Read the number of matches `N`.
2. Read the scores for each match, `X_i` and `Y_i`.
3. Sum the scores for Team Takahashi and Team Aoki separately.
4. Compare the total scores of both teams.
5. Print the appropriate winner based on the total scores.

Let's implement this in Python:
```python
# Read the number of matches
N = int(input())

# Initialize total scores for both teams
takahashi_score = 0
aoki_score = 0

# Read the scores for each match and update the total scores
for _ in range(N):
    x_i, y_i = map(int, input().split())
    takahashi_score += x_i
    aoki_score += y_i

# Determine the winner
if takahashi_score > aoki_score:
    print("Takahashi")
elif takahashi_score < aoki_score:
    print("Aoki")
else:
    print("Draw")
```
````

### Extracted final code

````python
# Read the number of matches
N = int(input())

# Initialize total scores for both teams
takahashi_score = 0
aoki_score = 0

# Read the scores for each match and update the total scores
for _ in range(N):
    x_i, y_i = map(int, input().split())
    takahashi_score += x_i
    aoki_score += y_i

# Determine the winner
if takahashi_score > aoki_score:
    print("Takahashi")
elif takahashi_score < aoki_score:
    print("Aoki")
else:
    print("Draw")

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 13,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 585,
  "completion_tokens": 87,
  "gen_seconds": 1.87,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
```python
from sys import stdin
input = stdin.readline

N = int(input())
TA = 0
AO = 0
for _ in range(N):
    x, y = map(int, input().split())
    TA += x
    AO += y
if TA > AO:
    print("Takahashi")
elif AO > TA:
    print("Aoki")
else:
    print("Draw")
```
````

### Extracted final code

````python
from sys import stdin
input = stdin.readline

N = int(input())
TA = 0
AO = 0
for _ in range(N):
    x, y = map(int, input().split())
    TA += x
    AO += y
if TA > AO:
    print("Takahashi")
elif AO > TA:
    print("Aoki")
else:
    print("Draw")

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 13,
  "num_tests": 13,
  "finish_reason": "stop",
  "prompt_tokens": 585,
  "completion_tokens": 310,
  "gen_seconds": 6.44,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
The problem involves calculating the total scores of two teams based on the points scored in each of the \(N\) matches. The team with the higher total score wins. If the scores are equal, it's a draw. We need to sum the scores for both teams and compare them.

Let's break down the steps:

1. Read the number of matches \(N\).
2. For each match, read the points scored by Team Takahashi (\(X_i\)) and Team Aoki (\(Y_i\)).
3. Sum the points scored by Team Takahashi and Team Aoki.
4. Compare the two totals to determine the winner or if it's a draw.

Here is the Python code to solve the problem:

```python
# Read the number of matches
N = int(input())

# Initialize total scores for both teams
total_takahashi = 0
total_aoki = 0

# Process each match
for _ in range(N):
    X, Y = map(int, input().split())
    total_takahashi += X
    total_aoki += Y

# Determine the winner
if total_takahashi > total_aoki:
    print("Takahashi")
elif total_takahashi < total_aoki:
    print("Aoki")
else:
    print("Draw")
```

This solution reads the number of matches first, then iterates through the matches, summing the points for each team. Finally, it compares the totals to determine the winner or a draw.
````

### Extracted final code

````python
# Read the number of matches
N = int(input())

# Initialize total scores for both teams
total_takahashi = 0
total_aoki = 0

# Process each match
for _ in range(N):
    X, Y = map(int, input().split())
    total_takahashi += X
    total_aoki += Y

# Determine the winner
if total_takahashi > total_aoki:
    print("Takahashi")
elif total_takahashi < total_aoki:
    print("Aoki")
else:
    print("Draw")

````

### Test result

````json
null
````
