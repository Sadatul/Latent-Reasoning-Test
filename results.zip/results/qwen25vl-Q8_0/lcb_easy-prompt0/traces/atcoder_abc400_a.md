# atcoder_abc400_a — PASS (3/3 attempts passed)

````json
{
  "id": "atcoder_abc400_a",
  "title": "ABC400 Party",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2025-04-05",
  "format": "stdin",
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 3
}
````

## User prompt

````text
### Question:
In the ceremony commemorating ABC400, we want to arrange 400 people in a rectangular formation of A rows and B columns without any gaps.
You are given a positive integer A. Print the value of a positive integer B for which such an arrangement is possible. If there is no such positive integer B, print -1.

Input

The input is given from Standard Input in the following format:
A

Output

Print the value of B or -1 as specified by the problem statement.

Constraints


- A is an integer between 1 and 400, inclusive.

Sample Input 1

10

Sample Output 1

40

We can arrange 400 people in 10 rows and 40 columns.

Sample Input 2

11

Sample Output 2

-1

Sample Input 3

400

Sample Output 3

1

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

First, think through the problem step by step: restate what is asked, work out an algorithm, and check it against the examples. Then give your complete solution as a single ```python code block at the end of your answer.
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 43,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 292,
  "completion_tokens": 278,
  "gen_seconds": 6.16,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine if we can arrange 400 people in a rectangular formation of `A` rows and `B` columns. The key is to find out if `B` exists such that `A * B = 400`.

Here's the step-by-step approach:

1. If `A` is a factor of 400, then `B` can be calculated as `400 / A`.
2. If `A` is not a factor of 400, then `B` does not exist, and we should print `-1`.

Let's implement this in Python:

```python
# Read input
A = int(input())

# Check if A is a factor of 400
if 400 % A == 0:
    B = 400 // A
    print(B)
else:
    print(-1)
```

This code reads the integer `A` from the standard input, checks if `A` is a factor of 400, and prints the result accordingly. If `A` is not a factor of 400, it prints `-1`. If `A` is a factor, it calculates and prints `B` (the number of columns) which satisfies the condition `A * B = 400`.
````

### Extracted final code

````python
# Read input
A = int(input())

# Check if A is a factor of 400
if 400 % A == 0:
    B = 400 // A
    print(B)
else:
    print(-1)

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 43,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 292,
  "completion_tokens": 459,
  "gen_seconds": 10.02,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
Sure, let's break down the problem step by step:

1. **Understanding the Problem**: We need to find a positive integer \( B \) such that \( A \times B = 400 \). This means \( B \) is the quotient when 400 is divided by \( A \).

2. **Input**: The input will be a positive integer \( A \).

3. **Output**: If we can find an integer \( B \) such that \( A \times B = 400 \), we should print \( B \). If no such \( B \) exists, print -1.

4. **Algorithm**:
   - Calculate \( B \) by dividing 400 by \( A \).
   - Check if the result is an integer.
   - If it is, print \( B \).
   - If not, print -1.

Now, let's implement this in Python:

```python
# Read the input value A
A = int(input())

# Calculate B
B = 400 // A

# Check if B is an integer
if B * A == 400:
    print(B)
else:
    print(-1)
```

This program will read the input integer \( A \), compute the integer division of 400 by \( A \), and then check if the result is an integer. If it is, it will print the result; otherwise, it will print -1.

Let's verify it with the provided sample inputs:

- For \( A = 10 \):
  - \( 400 / 10 = 40 \)
  - Result: 40 (integer, so print 40)

- For \( A = 11 \):
  - \( 400 / 11 \approx 36.36 \)
  - Result: -1 (not an integer, so print -1)

- For \( A = 400 \):
  - \( 400 / 400 = 1 \)
  - Result: 1 (integer, so print 1)

This code should correctly solve the problem as per the requirements.
````

### Extracted final code

````python
# Read the input value A
A = int(input())

# Calculate B
B = 400 // A

# Check if B is an integer
if B * A == 400:
    print(B)
else:
    print(-1)

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 43,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 292,
  "completion_tokens": 395,
  "gen_seconds": 8.7,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine if we can arrange 400 people in a rectangular formation of A rows and B columns such that the total number of people (which is 400) is equal to the product of A and B (i.e., \( A \times B = 400 \)). If such a B exists, we can print B. If no such B exists, we print -1.

### Steps:

1. **Input**: Read an integer \( A \) from the standard input.
2. **Calculation**: Compute \( B = \frac{400}{A} \).
3. **Check**: If \( B \) is an integer, print \( B \). If \( B \) is not an integer, print -1.

### Example:

- For \( A = 10 \):
  - \( B = \frac{400}{10} = 40 \)
  - Print \( B = 40 \).

- For \( A = 11 \):
  - \( B = \frac{400}{11} \) (not an integer)
  - Print -1.

- For \( A = 400 \):
  - \( B = \frac{400}{400} = 1 \)
  - Print \( B = 1 \).

### Python Code:

```python
# Read the integer A from the standard input
A = int(input())

# Calculate B
B = 400 // A

# Check if B is an integer (using modulo operation)
if B * A == 400:
    print(B)
else:
    print(-1)
```

This code ensures that we determine the integer \( B \) such that \( A \times B = 400 \) and print the correct result based on this condition.
````

### Extracted final code

````python
# Read the integer A from the standard input
A = int(input())

# Calculate B
B = 400 // A

# Check if B is an integer (using modulo operation)
if B * A == 400:
    print(B)
else:
    print(-1)

````

### Test result

````json
null
````
