# leetcode_3349 — PASS (3/3 attempts passed)

````json
{
  "id": "leetcode_3349",
  "title": "maximum-length-substring-with-two-occurrences",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "leetcode",
  "difficulty": "easy",
  "contest_date": "2024-03-23",
  "format": "functional",
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 3
}
````

## User prompt

````text
### Question:
Given a string s, return the maximum length of a substring such that it contains at most two occurrences of each character.
 
Example 1:

Input: s = "bcbbbcba"
Output: 4
Explanation:
The following substring has a length of 4 and contains at most two occurrences of each character: "bcbbbcba".
Example 2:

Input: s = "aaaa"
Output: 2
Explanation:
The following substring has a length of 2 and contains at most two occurrences of each character: "aaaa".
 
Constraints:

2 <= s.length <= 100
s consists only of lowercase English letters.

### Format: You will use the following starter code to write the solution to the problem and enclose your code within delimiters.
```python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        
```

First, think through the problem step by step: restate what is asked, work out an algorithm, and check it against the examples. Then give your complete solution as a single ```python code block at the end of your answer.
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 27,
  "num_tests": 27,
  "finish_reason": "stop",
  "prompt_tokens": 251,
  "completion_tokens": 390,
  "gen_seconds": 8.71,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we can use a sliding window approach to maintain a substring that contains at most two occurrences of each character. Here's a step-by-step plan:

1. **Initialize counters**: We'll use dictionaries to keep track of the count of each character in the current window.
2. **Initialize pointers**: Use two pointers to represent the window's start and end.
3. **Expand the window**: Move the end pointer to the right, adding characters to the window's count.
4. **Shrink the window**: If any character count exceeds two, move the start pointer to the right, removing characters from the window's count.
5. **Update the maximum length**: Keep track of the maximum length of the valid window found.
6. **Return the result**: After processing all characters, return the maximum length found.

Let's implement this in the code:

```python
from collections import defaultdict

class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        char_count = defaultdict(int)
        max_length = 0
        left = 0
        for right in range(len(s)):
            char_count[s[right]] += 1
            while char_count[s[right]] > 2:
                char_count[s[left]] -= 1
                left += 1
            max_length = max(max_length, right - left + 1)
        return max_length
```

In this solution:
- We use `defaultdict` to store the count of characters within the window and another `left` pointer to keep track of the start of the window.
- As we iterate through the string, we update the character count. If any character count exceeds two, we shrink the window from the left.
- We update the maximum length of the valid window whenever a valid window is found.

This approach ensures that we find the maximum length substring with at most two occurrences of each character efficiently.
````

### Extracted final code

````python
from collections import defaultdict

class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        char_count = defaultdict(int)
        max_length = 0
        left = 0
        for right in range(len(s)):
            char_count[s[right]] += 1
            while char_count[s[right]] > 2:
                char_count[s[left]] -= 1
                left += 1
            max_length = max(max_length, right - left + 1)
        return max_length

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 27,
  "num_tests": 27,
  "finish_reason": "stop",
  "prompt_tokens": 251,
  "completion_tokens": 558,
  "gen_seconds": 12.33,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
Sure, let's break down the problem step by step:

1. **Understanding the Problem**: We need to find the longest substring that contains at most two occurrences of each character. This means, for any character in the substring, it should not exceed two occurrences.

2. **Algorithm**:
   - Use a sliding window approach to maintain a substring that satisfies the condition.
   - Use a dictionary to keep track of the count of each character in the current window.
   - Expand the window by adding the next character and update the count.
   - If the count of any character exceeds two, shrink the window from the left until the condition is satisfied again.
   - Keep track of the maximum length of the window seen while satisfying the condition.

3. **Example Walkthrough**:
   - For "bcbbbcba", we start with "b" and add characters to the window. The first part "b" satisfies the condition.
   - When we add 'c', it also satisfies the condition.
   - For 'b', we have 'b', 'c', 'b', 'b', 'c', 'b'. Here, 'b' has three occurrences, so we shrink the window from the left.

4. **Implementation**:
   - Use a dictionary to count the characters.
   - Use two pointers to represent the window (left and right).

Here is the Python solution:

```python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        left = 0
        max_length = 0
        char_count = {}
        
        for right in range(len(s)):
            if s[right] in char_count:
                char_count[s[right]] += 1
            else:
                char_count[s[right]] = 1
            
            while any(count > 2 for count in char_count.values()):
                char_count[s[left]] -= 1
                if char_count[s[left]] == 0:
                    del char_count[s[left]]
                left += 1
            
            max_length = max(max_length, right - left + 1)
        
        return max_length
```

### Explanation:

- We initialize `left` to 0 and `max_length` to 0.
- Use a dictionary `char_count` to keep track of the count of each character in the current window.
- Iterate through the string with the `right` pointer, adding characters to the dictionary and updating the count.
- If at any point, any character's count exceeds 2, we move the `left` pointer to the right until the condition is satisfied again.
- Keep updating `max_length` with the maximum length of the window found.

This algorithm ensures that we find the longest valid substring efficiently.
````

### Extracted final code

````python
class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        left = 0
        max_length = 0
        char_count = {}
        
        for right in range(len(s)):
            if s[right] in char_count:
                char_count[s[right]] += 1
            else:
                char_count[s[right]] = 1
            
            while any(count > 2 for count in char_count.values()):
                char_count[s[left]] -= 1
                if char_count[s[left]] == 0:
                    del char_count[s[left]]
                left += 1
            
            max_length = max(max_length, right - left + 1)
        
        return max_length

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 27,
  "num_tests": 27,
  "finish_reason": "stop",
  "prompt_tokens": 251,
  "completion_tokens": 530,
  "gen_seconds": 11.65,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to find the longest substring that contains at most two occurrences of each character. Here's a step-by-step approach to achieve this:

1. **Initialization**: We initialize a dictionary `char_count` to keep track of the counts of each character in the current substring and a variable `max_length` to store the maximum length of the valid substring.

2. **Sliding Window Technique**: We use a sliding window approach where we maintain the current substring and adjust the window size as we iterate through the string.

3. **Character Tracking**: As we iterate through the string, we update the character count. If a character exceeds two occurrences, we shrink the window from the left until the character count is back to at most two.

4. **Update Maximum Length**: We update the `max_length` whenever we find a longer valid substring.

5. **Result**: After iterating through the string, we return the `max_length`.

Let's implement this approach:

```python
from collections import defaultdict

class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        char_count = defaultdict(int)
        start = 0
        max_length = 0
        
        for end in range(len(s)):
            char_count[s[end]] += 1
            
            # If any character count exceeds 2, shrink the window from the left
            while char_count[s[end]] > 2:
                char_count[s[start]] -= 1
                start += 1
            
            # Update max_length
            max_length = max(max_length, end - start + 1)
        
        return max_length
```

This solution works as follows:

- We initialize `char_count` as an empty dictionary and set the start index of the sliding window to 0.
- We iterate through the string with the `end` index, updating the count of the current character.
- If the count of any character exceeds 2, we shrink the window from the left by incrementing the `start` index until the count of the character is back to at most two.
- We update `max_length` with the current length of the window (`end - start + 1`).
- Finally, we return `max_length`.

This approach ensures that we efficiently find the longest substring with at most two occurrences of each character. The time complexity is O(n) where n is the length of the string, and the space complexity is O(1) since the dictionary `char_count` will not exceed the number of unique characters (which is fixed and at most 26 for lowercase English letters).
````

### Extracted final code

````python
from collections import defaultdict

class Solution:
    def maximumLengthSubstring(self, s: str) -> int:
        char_count = defaultdict(int)
        start = 0
        max_length = 0
        
        for end in range(len(s)):
            char_count[s[end]] += 1
            
            # If any character count exceeds 2, shrink the window from the left
            while char_count[s[end]] > 2:
                char_count[s[start]] -= 1
                start += 1
            
            # Update max_length
            max_length = max(max_length, end - start + 1)
        
        return max_length

````

### Test result

````json
null
````
