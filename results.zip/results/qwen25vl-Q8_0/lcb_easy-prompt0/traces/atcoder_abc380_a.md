# atcoder_abc380_a — PASS (3/3 attempts passed)

````json
{
  "id": "atcoder_abc380_a",
  "title": "123233",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-11-16",
  "format": "stdin",
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 3
}
````

## User prompt

````text
### Question:
You are given a 6-digit positive integer N.
Determine whether N satisfies all of the following conditions.

- Among the digits of N, the digit 1 appears exactly once.
- Among the digits of N, the digit 2 appears exactly twice.
- Among the digits of N, the digit 3 appears exactly three times.

Input

The input is given from Standard Input in the following format:
N

Output

Print Yes if N satisfies all the conditions described in the problem statement, and No otherwise, in one line.

Constraints


- N is an integer satisfying 100000 \le N \le 999999.

Sample Input 1

123233

Sample Output 1

Yes

123233 satisfies the conditions in the problem statement, so print Yes.

Sample Input 2

123234

Sample Output 2

No

123234 does not satisfy the conditions in the problem statement, so print No.

Sample Input 3

323132

Sample Output 3

Yes

Sample Input 4

500000

Sample Output 4

No

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

First, think through the problem step by step: restate what is asked, work out an algorithm, and check it against the examples. Then give your complete solution as a single ```python code block at the end of your answer.
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 354,
  "completion_tokens": 393,
  "gen_seconds": 8.71,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if the given 6-digit number `N` satisfies the following conditions:

1. The digit 1 appears exactly once.
2. The digit 2 appears exactly twice.
3. The digit 3 appears exactly three times.

Given that the number is 6 digits long, and the digits must satisfy the above conditions, the remaining digits must be 0 or 4 or 5 or 6 or 7 or 8 or 9, but they will not affect the counts of 1, 2, and 3. Therefore, we only need to check the counts of 1, 2, and 3.

Here is the step-by-step algorithm:

1. Convert the number to a string to easily access each digit.
2. Count the occurrences of '1', '2', and '3'.
3. Check if the count of '1' is exactly once, the count of '2' is exactly twice, and the count of '3' is exactly three times.
4. If all conditions are met, return "Yes"; otherwise, return "No".

Now, let's implement this in Python:

```python
# Read the input number
N = int(input())

# Convert the number to a string and count the digits
digits = str(N)
count_1 = digits.count('1')
count_2 = digits.count('2')
count_3 = digits.count('3')

# Check if the counts match the required conditions
if count_1 == 1 and count_2 == 2 and count_3 == 3:
    print("Yes")
else:
    print("No")
```

This solution reads the input number, counts the occurrences of the digits '1', '2', and '3', and then checks if these counts match the required values. If they do, it prints "Yes"; otherwise, it prints "No".
````

### Extracted final code

````python
# Read the input number
N = int(input())

# Convert the number to a string and count the digits
digits = str(N)
count_1 = digits.count('1')
count_2 = digits.count('2')
count_3 = digits.count('3')

# Check if the counts match the required conditions
if count_1 == 1 and count_2 == 2 and count_3 == 3:
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 354,
  "completion_tokens": 77,
  "gen_seconds": 1.74,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
```python
digit_count = [0] * 10
n = int(input())

for digit in str(n):
    digit_count[int(digit)] += 1

if digit_count[1] == 1 and digit_count[2] == 2 and digit_count[3] == 3:
    print("Yes")
else:
    print("No")
```
````

### Extracted final code

````python
digit_count = [0] * 10
n = int(input())

for digit in str(n):
    digit_count[int(digit)] += 1

if digit_count[1] == 1 and digit_count[2] == 2 and digit_count[3] == 3:
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 44,
  "num_tests": 44,
  "finish_reason": "stop",
  "prompt_tokens": 354,
  "completion_tokens": 447,
  "gen_seconds": 9.82,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if the given 6-digit number `N` satisfies the following conditions:
1. The digit `1` appears exactly once.
2. The digit `2` appears exactly twice.
3. The digit `3` appears exactly three times.

Here's a step-by-step approach to solve this:

1. Convert the number `N` to a string so that we can iterate over its digits.
2. Count the occurrences of each digit `1`, `2`, and `3` in the string representation of `N`.
3. Use these counts to check if they match the required conditions.

Let's implement this in Python:

```python
# Read the input number
N = int(input().strip())

# Convert the number to a string
N_str = str(N)

# Initialize counters for digits 1, 2, and 3
count_1 = 0
count_2 = 0
count_3 = 0

# Iterate over each digit in the string representation of N
for digit in N_str:
    if digit == '1':
        count_1 += 1
    elif digit == '2':
        count_2 += 1
    elif digit == '3':
        count_3 += 1

# Check if the counts match the required conditions
if count_1 == 1 and count_2 == 2 and count_3 == 3:
    print('Yes')
else:
    print('No')
```

### Explanation:
- We convert the input number `N` to a string so we can easily iterate over each digit.
- We initialize three counters: `count_1`, `count_2`, and `count_3` to zero.
- We iterate over each character in the string representation of `N` and increment the respective counter based on the digit.
- Finally, we check if the counts match the required conditions (1=1, 2=2, 3=3).
- If the conditions are met, we print 'Yes'; otherwise, we print 'No'.

This solution efficiently checks the condition requirements for any given 6-digit number `N`.
````

### Extracted final code

````python
# Read the input number
N = int(input().strip())

# Convert the number to a string
N_str = str(N)

# Initialize counters for digits 1, 2, and 3
count_1 = 0
count_2 = 0
count_3 = 0

# Iterate over each digit in the string representation of N
for digit in N_str:
    if digit == '1':
        count_1 += 1
    elif digit == '2':
        count_2 += 1
    elif digit == '3':
        count_3 += 1

# Check if the counts match the required conditions
if count_1 == 1 and count_2 == 2 and count_3 == 3:
    print('Yes')
else:
    print('No')

````

### Test result

````json
null
````
