# atcoder_abc363_a — WRONG_ANSWER (0/3 attempts passed)

````json
{
  "id": "atcoder_abc363_a",
  "title": "Piling Up",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-07-20",
  "format": "stdin",
  "status": "wrong_answer",
  "passes": 3,
  "num_attempts_passed": 0
}
````

## User prompt

````text
### Question:
In AtCoder, a user's rating is given as a positive integer, and based on this value, a certain number of ^ is displayed.
Specifically, when the rating is between 1 and 399, inclusive, the display rules are as follows:

- When the rating is between 1 and 99, inclusive, ^ is displayed once.
- When the rating is between 100 and 199, inclusive, ^ is displayed twice.
- When the rating is between 200 and 299, inclusive, ^ is displayed three times.
- When the rating is between 300 and 399, inclusive, ^ is displayed four times.

Currently, Takahashi's rating is R. Here, it is guaranteed that R is an integer between 1 and 299, inclusive.
Find the minimum increase in rating required for him to increase the number of displayed ^.
It can be proved that under the constraints of this problem, he can increase the number of ^ without raising his rating to 400 or above.

Input

The input is given from Standard Input in the following format:
R

Output

Print, as an integer, the minimum increase in rating required for Takahashi to increase the number of displayed ^.

Constraints


- 1 \leq R \leq 299
- R is an integer.

Sample Input 1

123

Sample Output 1

77

Takahashi's current rating is 123, and ^ is displayed twice.
By increasing his rating by 77, his rating will become 200, and ^ will be displayed three times.
When the rating is 199 or below, ^ is displayed not more than twice, so print 77.

Sample Input 2

250

Sample Output 2

50

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

First, think through the problem step by step: restate what is asked, work out an algorithm, and check it against the examples. Then give your complete solution as a single ```python code block at the end of your answer.
````

## Attempt 1 — WRONG_ANSWER

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "wrong_answer",
  "num_passed": 1,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 496,
  "completion_tokens": 665,
  "gen_seconds": 14.76,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine the minimum increase in Takahashi's rating that will allow him to increase the number of displayed `^` symbols. The rules for the number of `^` symbols displayed are as follows:

- For a rating between 1 and 99, `^` is displayed once.
- For a rating between 100 and 199, `^` is displayed twice.
- For a rating between 200 and 299, `^` is displayed three times.
- For a rating of 400 or above, `^` is displayed four times.

Given that Takahashi's current rating is `R` and it is guaranteed that `R` is between 1 and 299, we need to find the smallest increase in `R` that will cause `^` to be displayed three times.

Here's the algorithm:
1. If `R` is in the range [1, 99], the next step is to reach a rating that displays `^` 2 times (i.e., `R = 100`).
2. If `R` is in the range [100, 199], the next step is to reach a rating that displays `^` 3 times (i.e., `R = 200`).
3. If `R` is in the range [200, 299], no increase is required because `^` is already displayed three times.

The minimum increase in rating required for each case can be calculated as follows:
- For `R` in [1, 99]: `100 - R`
- For `R` in [100, 199]: `200 - R`
- For `R` in [200, 299]: `0` (no increase needed)

Let's implement this in Python:

```python
# Read the input rating R
R = int(input())

# Calculate the minimum increase in rating required
if R <= 99:
    increase = 100 - R
elif R <= 199:
    increase = 200 - R
else:
    increase = 0

# Print the result
print(increase)
```

### Explanation of the Code:
1. **Input**: The rating `R` is read from standard input.
2. **Conditions**:
   - If `R` is between 1 and 99, the increase needed to reach the next range (100 to 199) is `100 - R`.
   - If `R` is between 100 and 199, the increase needed to reach the next range (200 to 299) is `200 - R`.
   - If `R` is between 200 and 299, no increase is needed since `^` is already displayed three times.
3. **Output**: The minimum increase is printed to standard output.

This solution efficiently handles the problem by directly calculating the required increase based on the current rating `R`.
````

### Extracted final code

````python
# Read the input rating R
R = int(input())

# Calculate the minimum increase in rating required
if R <= 99:
    increase = 100 - R
elif R <= 199:
    increase = 200 - R
else:
    increase = 0

# Print the result
print(increase)

````

### Test result

````json
{
  "test_index": 1,
  "input": "250\n",
  "expected": "50\n",
  "got": "0\n",
  "error": null
}
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 496,
  "completion_tokens": 62,
  "gen_seconds": 1.39,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
```python
rating = int(input())
displayed = rating // 100
remaining = rating % 100

if displayed == 3:
    print(100 - remaining)
else:
    print(100 * (displayed + 1) - remaining)
```
````

### Extracted final code

````python
rating = int(input())
displayed = rating // 100
remaining = rating % 100

if displayed == 3:
    print(100 - remaining)
else:
    print(100 * (displayed + 1) - remaining)

````

### Test result

````json
{
  "test_index": 0,
  "input": "123\n",
  "expected": "77\n",
  "got": "177\n",
  "error": null
}
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 1,
  "num_tests": 14,
  "finish_reason": "stop",
  "prompt_tokens": 496,
  "completion_tokens": 511,
  "gen_seconds": 11.2,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine the minimum increase in rating required for Takahashi's rating to change the number of displayed `^` symbols. Here's a step-by-step approach:

1. Identify the current rating and the number of `^` symbols it displays.
2. Determine the target rating such that the number of `^` symbols increases by one.

### Analysis:
- When the rating is between 1 and 99, `^` is displayed once.
- When the rating is between 100 and 199, `^` is displayed twice.
- When the rating is between 200 and 299, `^` is displayed three times.

To increase the number of `^` symbols, the current rating should be in the range `[1, 99]` and the target should be in the range `[200, 299]`.

### Calculation:
- If the current rating `R` is in the range `[1, 99]`, the target rating should be in the range `[200, 299]`.
- The difference in the number of `^` symbols is `3 - 1 = 2`.
- Therefore, the increase in rating needed is `200 - R`.

However, if the current rating is already in the range `[100, 199]`, we need to increase the rating to get to the next range where the number of `^` symbols increases by one. 

### Complete Solution:
We will read the input rating `R`, and calculate the minimum increase in rating based on the above logic.

```python
# Read the input rating
R = int(input())

# Determine the minimum increase in rating
if R <= 99:
    # If the current rating is in the range [1, 99], increase to the range [200, 299]
    increase = 200 - R
else:
    # If the current rating is already in the range [100, 199], increase to the range [200, 299]
    increase = 200 - R

# Output the minimum increase in rating
print(increase)
```

This code snippet reads the current rating `R` as an integer and calculates the minimum increase in rating required to increase the number of `^` symbols. It then prints the result.
````

### Extracted final code

````python
# Read the input rating
R = int(input())

# Determine the minimum increase in rating
if R <= 99:
    # If the current rating is in the range [1, 99], increase to the range [200, 299]
    increase = 200 - R
else:
    # If the current rating is already in the range [100, 199], increase to the range [200, 299]
    increase = 200 - R

# Output the minimum increase in rating
print(increase)

````

### Test result

````json
{
  "test_index": 1,
  "input": "250\n",
  "expected": "50\n",
  "got": "-50\n",
  "error": null
}
````
