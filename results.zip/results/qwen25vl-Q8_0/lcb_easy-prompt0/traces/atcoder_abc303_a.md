# atcoder_abc303_a — PASS (2/3 attempts passed)

````json
{
  "id": "atcoder_abc303_a",
  "title": "Similar String",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2023-05-27",
  "format": "stdin",
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 2
}
````

## User prompt

````text
### Question:
Two characters x and y are called similar characters if and only if one of the following conditions is satisfied:

- x and y are the same character.
- One of x and y is 1 and the other is l.
- One of x and y is 0 and the other is o.

Two strings S and T, each of length N, are called similar strings if and only if:

- for all i\ (1\leq i\leq N), the i-th character of S and the i-th character of T are similar characters.

Given two length-N strings S and T consisting of lowercase English letters and digits, determine if S and T are similar strings.

Input

The input is given from Standard Input in the following format:
N
S
T

Output

Print Yes if S and T are similar strings, and No otherwise.

Constraints


- N is an integer between 1 and 100.
- Each of S and T is a string of length N consisting of lowercase English letters and digits.

Sample Input 1

3
l0w
1ow

Sample Output 1

Yes

The 1-st character of S is l, and the 1-st character of T is 1.  These are similar characters.
The 2-nd character of S is 0, and the 2-nd character of T is o.  These are similar characters.
The 3-rd character of S is w, and the 3-rd character of T is w.  These are similar characters.
Thus, S and T are similar strings.

Sample Input 2

3
abc
arc

Sample Output 2

No

The 2-nd character of S is b, and the 2-nd character of T is r.  These are not similar characters.
Thus, S and T are not similar strings.

Sample Input 3

4
nok0
n0ko

Sample Output 3

Yes

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

First, think through the problem step by step: restate what is asked, work out an algorithm, and check it against the examples. Then give your complete solution as a single ```python code block at the end of your answer.
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 15,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 511,
  "completion_tokens": 489,
  "gen_seconds": 10.87,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if each character in string `S` can be mapped to the corresponding character in string `T` such that they are similar according to the given rules. Here's a step-by-step approach:

1. **Identify Similar Characters**: 
   - `l` and `1`
   - `o` and `0`
   - Any character that matches itself

2. **Compare Characters**:
   - For each character in `S` and `T`, check if they are similar according to the rules.

3. **Output Result**:
   - If all characters are similar, print "Yes".
   - If any character pair is not similar, print "No".

Here's the Python code to implement this logic:

```python
def are_similar(S, T):
    N = len(S)
    for i in range(N):
        s_char = S[i]
        t_char = T[i]
        
        # Check if characters are similar
        if (s_char == t_char) or (s_char == 'l' and t_char == '1') or (s_char == '1' and t_char == 'l') or (s_char == '0' and t_char == 'o') or (s_char == 'o' and t_char == '0'):
            continue
        else:
            return False
    return True

def main():
    N = int(input())
    S = input()
    T = input()
    
    result = "Yes" if are_similar(S, T) else "No"
    print(result)

if __name__ == "__main__":
    main()
```

### Explanation:
1. **Function `are_similar`**:
   - Takes two strings `S` and `T` as input.
   - Compares each character in `S` with the corresponding character in `T`.
   - Uses a conditional statement to check if the characters are similar according to the given rules.
   - Returns `True` if all characters are similar and `False` otherwise.

2. **Function `main`**:
   - Reads the input values `N`, `S`, and `T`.
   - Calls the `are_similar` function and prints the result based on the returned boolean value.

This solution ensures that the input strings are checked against the similarity rules and outputs the appropriate result.
````

### Extracted final code

````python
def are_similar(S, T):
    N = len(S)
    for i in range(N):
        s_char = S[i]
        t_char = T[i]
        
        # Check if characters are similar
        if (s_char == t_char) or (s_char == 'l' and t_char == '1') or (s_char == '1' and t_char == 'l') or (s_char == '0' and t_char == 'o') or (s_char == 'o' and t_char == '0'):
            continue
        else:
            return False
    return True

def main():
    N = int(input())
    S = input()
    T = input()
    
    result = "Yes" if are_similar(S, T) else "No"
    print(result)

if __name__ == "__main__":
    main()

````

### Test result

````json
null
````

## Attempt 2 — WRONG_ANSWER

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "wrong_answer",
  "num_passed": 0,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 511,
  "completion_tokens": 105,
  "gen_seconds": 2.38,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
```python
from sys import stdin

def solve():
    N = int(stdin.readline())
    S = stdin.readline().rstrip()
    T = stdin.readline().rstrip()
    for i in range(N):
        if S[i] == '1' and T[i] == 'l':
            continue
        if S[i] == '0' and T[i] == 'o':
            continue
        if S[i] != T[i]:
            return 'No'
    return 'Yes'

print(solve())
```
````

### Extracted final code

````python
from sys import stdin

def solve():
    N = int(stdin.readline())
    S = stdin.readline().rstrip()
    T = stdin.readline().rstrip()
    for i in range(N):
        if S[i] == '1' and T[i] == 'l':
            continue
        if S[i] == '0' and T[i] == 'o':
            continue
        if S[i] != T[i]:
            return 'No'
    return 'Yes'

print(solve())

````

### Test result

````json
{
  "test_index": 0,
  "input": "3\nl0w\n1ow\n",
  "expected": "Yes\n",
  "got": "No\n",
  "error": null
}
````

## Attempt 3 — PASS

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "pass",
  "num_passed": 15,
  "num_tests": 15,
  "finish_reason": "stop",
  "prompt_tokens": 511,
  "completion_tokens": 424,
  "gen_seconds": 9.34,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to determine if two strings `S` and `T` are similar based on the given conditions. Here's a step-by-step approach:

1. **Check Similarity Condition**: We need to check if each corresponding pair of characters in `S` and `T` are similar according to the conditions provided.
2. **Parse Input**: The input consists of an integer `N`, followed by two strings `S` and `T`, each of length `N`.
3. **Output**: If all pairs of characters are similar, the output should be "Yes". Otherwise, it should be "No".

Let's implement this in Python:

```python
# Read the input
N = int(input())
S = input()
T = input()

# Function to check if two characters are similar
def are_similar(x, y):
    if x == y:
        return True
    if (x == '1' and y == 'l') or (x == 'l' and y == '1'):
        return True
    if (x == '0' and y == 'o') or (x == 'o' and y == '0'):
        return True
    return False

# Check if all pairs are similar
is_similar = all(are_similar(S[i], T[i]) for i in range(N))

# Output the result
if is_similar:
    print("Yes")
else:
    print("No")
```

### Explanation:
- **Input Reading**: The integer `N` is read first, followed by the strings `S` and `T`.
- **Similarity Check**: The `are_similar` function checks if two characters are similar based on the given conditions.
- **Group Check**: We use a list comprehension to iterate over the pairs of characters from `S` and `T` and check if they are similar.
- **Output**: If all pairs are similar, "Yes" is printed; otherwise, "No" is printed.

This solution handles all the given constraints and examples effectively.
````

### Extracted final code

````python
# Read the input
N = int(input())
S = input()
T = input()

# Function to check if two characters are similar
def are_similar(x, y):
    if x == y:
        return True
    if (x == '1' and y == 'l') or (x == 'l' and y == '1'):
        return True
    if (x == '0' and y == 'o') or (x == 'o' and y == '0'):
        return True
    return False

# Check if all pairs are similar
is_similar = all(are_similar(S[i], T[i]) for i in range(N))

# Output the result
if is_similar:
    print("Yes")
else:
    print("No")

````

### Test result

````json
null
````
