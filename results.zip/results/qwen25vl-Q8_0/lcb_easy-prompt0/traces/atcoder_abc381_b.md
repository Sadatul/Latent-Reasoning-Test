# atcoder_abc381_b — PASS (2/3 attempts passed)

````json
{
  "id": "atcoder_abc381_b",
  "title": "1122 String",
  "dataset": "lcb_easy",
  "model": "qwen25vl",
  "quant": "Q8_0",
  "platform": "atcoder",
  "difficulty": "easy",
  "contest_date": "2024-11-22",
  "format": "stdin",
  "status": "pass",
  "passes": 3,
  "num_attempts_passed": 2
}
````

## User prompt

````text
### Question:
A string T is called a 1122 string if and only if it satisfies all of the following three conditions:

- \lvert T \rvert is even. Here, \lvert T \rvert denotes the length of T.
- For each integer i satisfying 1\leq i\leq \frac{|T|}{2}, the (2i-1)-th and 2i-th characters of T are equal.
- Each character appears in T exactly zero or two times. That is, every character contained in T appears exactly twice in T.

Given a string S consisting of lowercase English letters, print Yes if S is a 1122 string, and No otherwise.

Input

The input is given from Standard Input in the following format:
S

Output

If S is a 1122 string, print Yes; otherwise, print No.

Constraints


- S is a string of length between 1 and 100, inclusive, consisting of lowercase English letters.

Sample Input 1

aabbcc

Sample Output 1

Yes

S=aabbcc satisfies all the conditions for a 1122 string, so print Yes.

Sample Input 2

aab

Sample Output 2

No

S=aab has an odd length and does not satisfy the first condition, so print No.

Sample Input 3

zzzzzz

Sample Output 3

No

S=zzzzzz contains six zs and does not satisfy the third condition, so print No.

### Format: Read the inputs from stdin, solve the problem and write the answer to stdout (do not directly test on the sample inputs). Write a complete Python program.

First, think through the problem step by step: restate what is asked, work out an algorithm, and check it against the examples. Then give your complete solution as a single ```python code block at the end of your answer.
````

## Attempt 1 — PASS

````json
{
  "attempt": 0,
  "seed": 0,
  "status": "pass",
  "num_passed": 43,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 419,
  "completion_tokens": 396,
  "gen_seconds": 8.85,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if the given string `S` meets all the criteria to be a 1122 string. Here's a step-by-step approach:

1. **Length Check**: The length of the string `S` must be even.
2. **Character Pair Check**: For each pair of characters at indices `2i-1` and `2i`, they must be equal.
3. **Character Count Check**: Each character in the string must appear exactly zero or two times.

Let's implement this in Python:

```python
s = input().strip()

# Step 1: Length check
if len(s) % 2 != 0:
    print("No")
    exit()

# Step 2: Pair character check
n = len(s) // 2
for i in range(n):
    if s[2*i] != s[2*i + 1]:
        print("No")
        exit()

# Step 3: Character count check
char_count = {}
for char in s:
    if char in char_count:
        char_count[char] += 1
    else:
        char_count[char] = 1

# Check if each character appears exactly zero or two times
for count in char_count.values():
    if count != 0 and count != 2:
        print("No")
        exit()

print("Yes")
```

This code first checks if the length of the string is even. If not, it prints "No" and exits. Then it checks if each pair of characters at indices `2i-1` and `2i` are equal. If not, it prints "No" and exits. Finally, it counts the occurrences of each character and checks if each character appears exactly zero or two times. If any character count is not zero or two, it prints "No" and exits. If all checks pass, it prints "Yes".
````

### Extracted final code

````python
s = input().strip()

# Step 1: Length check
if len(s) % 2 != 0:
    print("No")
    exit()

# Step 2: Pair character check
n = len(s) // 2
for i in range(n):
    if s[2*i] != s[2*i + 1]:
        print("No")
        exit()

# Step 3: Character count check
char_count = {}
for char in s:
    if char in char_count:
        char_count[char] += 1
    else:
        char_count[char] = 1

# Check if each character appears exactly zero or two times
for count in char_count.values():
    if count != 0 and count != 2:
        print("No")
        exit()

print("Yes")

````

### Test result

````json
null
````

## Attempt 2 — PASS

````json
{
  "attempt": 1,
  "seed": 1,
  "status": "pass",
  "num_passed": 43,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 419,
  "completion_tokens": 259,
  "gen_seconds": 5.7,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
```python
from collections import Counter

def is_1122_string(s):
    # Check if the length of the string is even
    if len(s) % 2 == 1:
        return "No"
    
    # Check if each character appears exactly twice or not at all
    char_counts = Counter(s)
    for count in char_counts.values():
        if count != 0 and count != 2:
            return "No"
    
    # Check if the first and second characters match, the third and fourth match, and so on
    for i in range(1, len(s), 2):
        if s[i-1] != s[i]:
            return "No"
    
    return "Yes"

# Read the input string
S = input()
print(is_1122_string(S))
```

This Python program first checks if the input string `S` satisfies the conditions of a 1122 string as described in the problem. It uses the `Counter` class from the `collections` module to count the occurrences of each character in the string and then iterates through the string to verify the matching condition. Finally, it prints "Yes" if the string meets all conditions, and "No" otherwise.
````

### Extracted final code

````python
from collections import Counter

def is_1122_string(s):
    # Check if the length of the string is even
    if len(s) % 2 == 1:
        return "No"
    
    # Check if each character appears exactly twice or not at all
    char_counts = Counter(s)
    for count in char_counts.values():
        if count != 0 and count != 2:
            return "No"
    
    # Check if the first and second characters match, the third and fourth match, and so on
    for i in range(1, len(s), 2):
        if s[i-1] != s[i]:
            return "No"
    
    return "Yes"

# Read the input string
S = input()
print(is_1122_string(S))

````

### Test result

````json
null
````

## Attempt 3 — WRONG_ANSWER

````json
{
  "attempt": 2,
  "seed": 2,
  "status": "wrong_answer",
  "num_passed": 2,
  "num_tests": 43,
  "finish_reason": "stop",
  "prompt_tokens": 419,
  "completion_tokens": 479,
  "gen_seconds": 10.51,
  "latent_token_count": 0,
  "added_special_tokens": {}
}
````

### Model output (full reasoning trace, special tokens included)

````text
To solve this problem, we need to check if the given string `S` satisfies the three conditions of a 1122 string. Here's a step-by-step approach:

1. **Length Check**: The length of the string `S` must be even.
2. **Equality Check**: For each integer `i` satisfying `1 ≤ i ≤ |S| / 2`, the `(2i-1)`-th and `2i`-th characters of `S` must be equal.
3. **Duplicate Check**: Each character in the string must appear exactly zero or two times.

Let's go through the solution step-by-step:

1. **Length Check**: We can check if the length of `S` is even.
2. **Equality Check**: We can use a loop or a list comprehension to verify that the characters at the even indices (considering the 1-based indexing) match the characters at the next odd index.
3. **Duplicate Check**: We can use a dictionary to count the occurrences of each character in the string.

Here is the complete Python code:

```python
def is_1122_string(S):
    n = len(S)
    
    # Length check
    if n % 2 != 0:
        return "No"
    
    # Equality check
    for i in range(1, n + 1, 2):
        if S[i-1] != S[i]:
            return "No"
    
    # Duplicate check
    char_count = {}
    for char in S:
        if char in char_count:
            char_count[char] += 1
        else:
            char_count[char] = 1
    
    # Check if each character is used even times
    for count in char_count.values():
        if count != 0 and count % 2 != 0:
            return "No"
    
    return "Yes"

# Read input
S = input().strip()

# Print the result
print(is_1122_string(S))
```

This code first checks the length of the string. Then, it verifies the equality of characters at even indices. Finally, it counts the occurrences of each character and ensures that each character appears an even number of times. If all checks pass, it returns "Yes"; otherwise, it returns "No".
````

### Extracted final code

````python
def is_1122_string(S):
    n = len(S)
    
    # Length check
    if n % 2 != 0:
        return "No"
    
    # Equality check
    for i in range(1, n + 1, 2):
        if S[i-1] != S[i]:
            return "No"
    
    # Duplicate check
    char_count = {}
    for char in S:
        if char in char_count:
            char_count[char] += 1
        else:
            char_count[char] = 1
    
    # Check if each character is used even times
    for count in char_count.values():
        if count != 0 and count % 2 != 0:
            return "No"
    
    return "Yes"

# Read input
S = input().strip()

# Print the result
print(is_1122_string(S))

````

### Test result

````json
{
  "test_index": 2,
  "input": "zzzzzz",
  "expected": "No",
  "got": "Yes\n",
  "error": null
}
````
